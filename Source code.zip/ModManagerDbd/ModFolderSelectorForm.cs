﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace ModManagerDbd
{
    public partial class ModFolderSelectorForm : Form
    {
        private const string AppDataPath = "ModManagerDbd\\selectedPath.txt";
        private Label selectedPathLabel;

        public string SelectedPath { get; private set; }

        public ModFolderSelectorForm()
        {
            ModInitializeComponent();
            LoadSelectedPath();
        }

        private void ModInitializeComponent()
        {
            this.Text = "Select Mod Folder";
            this.Size = new Size(400, 300);
            this.BackColor = ColorTranslator.FromHtml("#1a1b26");
            this.ForeColor = Color.White;
            this.FormBorderStyle = FormBorderStyle.None;
            this.StartPosition = FormStartPosition.CenterParent;

            Label titleLabel = new Label
            {
                Text = "Select the folder where your mods are located",
                Font = new Font("Arial", 10, FontStyle.Regular),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(20, 20)
            };
            this.Controls.Add(titleLabel);

            Button selectButton = new Button
            {
                Text = "Select Folder",
                Font = new Font("Arial", 10, FontStyle.Regular),
                ForeColor = Color.White,
                BackColor = ColorTranslator.FromHtml("#1a1b26"),
                Width = 150,
                Height = 30,
                FlatStyle = FlatStyle.Flat,
                Location = new Point(20, 60)
            };
            selectButton.Click += SelectButton_Click;
            this.Controls.Add(selectButton);

            selectedPathLabel = new Label
            {
                Font = new Font("Arial", 10, FontStyle.Regular),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(180, 65)
            };
            this.Controls.Add(selectedPathLabel);

            Button okButton = new Button
            {
                Text = "OK",
                Font = new Font("Arial", 10, FontStyle.Regular),
                ForeColor = Color.White,
                BackColor = ColorTranslator.FromHtml("#1a1b26"),
                Width = 50,
                Height = 30,
                FlatStyle = FlatStyle.Flat,
                Location = new Point(200, 100)
            };
            okButton.Click += OkButton_Click;
            this.Controls.Add(okButton);

            Button cancelButton = new Button
            {
                Text = "Cancel",
                Font = new Font("Arial", 10, FontStyle.Regular),
                ForeColor = Color.White,
                BackColor = ColorTranslator.FromHtml("#1a1b26"),
                Width = 70,
                Height = 30,
                FlatStyle = FlatStyle.Flat,
                Location = new Point(260, 100)
            };
            cancelButton.Click += (sender, e) => this.DialogResult = DialogResult.Cancel;
            this.Controls.Add(cancelButton);

        }








        private void SelectButton_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog folderDialog = new FolderBrowserDialog())
            {
                folderDialog.Description = "Select the folder where your mods are located";
                folderDialog.ShowNewFolderButton = false;

                if (folderDialog.ShowDialog() == DialogResult.OK)
                {
                    SelectedPath = folderDialog.SelectedPath;
                    selectedPathLabel.Text = SelectedPath;
                    SaveSelectedPath();
                }
            }
        }

        private void OkButton_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(SelectedPath))
            {
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                MessageBox.Show("Please select a folder.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SaveSelectedPath()
        {
            string appDataFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ModManagerDbd");
            Directory.CreateDirectory(appDataFolder);

            string pathFile = Path.Combine(appDataFolder, "selectedPath.txt");
            string[] lines = File.Exists(pathFile) ? File.ReadAllLines(pathFile) : new string[2];
            if (lines.Length < 2)
            {
                Array.Resize(ref lines, 2);
            }
            lines[1] = SelectedPath;
            File.WriteAllLines(pathFile, lines);
        }

        private void LoadSelectedPath()
        {
            string appDataFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ModManagerDbd");
            string pathFile = Path.Combine(appDataFolder, "selectedPath.txt");

            if (File.Exists(pathFile))
            {
                string[] lines = File.ReadAllLines(pathFile);
                if (lines.Length > 1)
                {
                    SelectedPath = lines[1];
                    selectedPathLabel.Text = SelectedPath;
                }
            }
        }
    }
}
