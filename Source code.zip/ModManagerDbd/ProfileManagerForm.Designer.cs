﻿using System.Drawing;
using System.Windows.Forms;

namespace ModManagerDbd
{
    partial class ProfileManagerForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.ListBox listBoxProfiles;
        private System.Windows.Forms.TextBox textBoxProfileName;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Button buttonRename;
        private System.Windows.Forms.Button buttonDelete;
        private System.Windows.Forms.Button buttonOK;
        private System.Windows.Forms.CheckBox checkBoxDefaultProfile;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.listBoxProfiles = new System.Windows.Forms.ListBox();
            this.textBoxProfileName = new System.Windows.Forms.TextBox();
            this.buttonAdd = CreateButton("Add", new Font("Arial", 10, FontStyle.Regular), Color.White, "#3a3b4a", new Size(75, 23), new Point(12, 244));
            this.buttonRename = CreateButton("Rename", new Font("Arial", 10, FontStyle.Regular), Color.White, "#3a3b4a", new Size(75, 23), new Point(93, 244));
            this.buttonDelete = CreateButton("Delete", new Font("Arial", 10, FontStyle.Regular), Color.White, "#3a3b4a", new Size(75, 23), new Point(174, 244));
            this.buttonOK = CreateButton("OK", new Font("Arial", 10, FontStyle.Regular), Color.White, "#3a3b4a", new Size(75, 23), new Point(197, 273));
            this.checkBoxDefaultProfile = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();

            this.listBoxProfiles.BackColor = ColorTranslator.FromHtml("#1a1b26");
            this.listBoxProfiles.ForeColor = Color.White;
            this.listBoxProfiles.FormattingEnabled = true;
            this.listBoxProfiles.Location = new System.Drawing.Point(12, 52);
            this.listBoxProfiles.Name = "listBoxProfiles";
            this.listBoxProfiles.Size = new System.Drawing.Size(260, 160);
            this.listBoxProfiles.TabIndex = 0;

            this.textBoxProfileName.BackColor = ColorTranslator.FromHtml("#1a1b26");
            this.textBoxProfileName.ForeColor = Color.White;
            this.textBoxProfileName.Location = new System.Drawing.Point(12, 218);
            this.textBoxProfileName.Name = "textBoxProfileName";
            this.textBoxProfileName.Size = new System.Drawing.Size(260, 20);
            this.textBoxProfileName.TabIndex = 1;

            this.checkBoxDefaultProfile.AutoSize = true;
            this.checkBoxDefaultProfile.ForeColor = Color.White;
            this.checkBoxDefaultProfile.Location = new System.Drawing.Point(12, 277);
            this.checkBoxDefaultProfile.Name = "checkBoxDefaultProfile";
            this.checkBoxDefaultProfile.Size = new System.Drawing.Size(91, 17);
            this.checkBoxDefaultProfile.TabIndex = 6;
            this.checkBoxDefaultProfile.Text = "Default Profile";
            this.checkBoxDefaultProfile.UseVisualStyleBackColor = true;

            this.ClientSize = new System.Drawing.Size(284, 311);
            this.Controls.Add(this.checkBoxDefaultProfile);
            this.Controls.Add(this.buttonOK);
            this.Controls.Add(this.buttonDelete);
            this.Controls.Add(this.buttonRename);
            this.Controls.Add(this.buttonAdd);
            this.Controls.Add(this.textBoxProfileName);
            this.Controls.Add(this.listBoxProfiles);
            this.Name = "ProfileManagerForm";
            this.Text = "Manage Profiles";
            this.BackColor = ColorTranslator.FromHtml("#1a1b26");
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private Button CreateButton(string text, Font font, Color foreColor, string backColor, Size size, Point location)
        {
            return new Button
            {
                Text = text,
                Font = font,
                ForeColor = foreColor,
                BackColor = ColorTranslator.FromHtml(backColor),
                FlatStyle = FlatStyle.Flat,
                Size = size,
                Location = location,
                Anchor = AnchorStyles.Top | AnchorStyles.Left
            };
        }
    }
}