﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ModManagerDbd
{
    public partial class ModManagerForm : Form
    {
        public ModManagerForm()
        {
            InitializeComponent();
            SetupUI();
        }

        private void SetupUI()
        {
            this.Text = "Mod Manager";
            this.Size = new Size(800, 600);
            this.BackColor = ColorTranslator.FromHtml("#1a1b26");
            this.ForeColor = Color.White;
            this.StartPosition = FormStartPosition.CenterScreen;

            Label placeholderLabel = new Label
            {
                Text = "Mod Manager Screen",
                Font = new Font("Arial", 20, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point((this.ClientSize.Width / 2) - 100, this.ClientSize.Height / 2),
                Anchor = AnchorStyles.None
            };
            this.Controls.Add(placeholderLabel);
        }
    }
}
