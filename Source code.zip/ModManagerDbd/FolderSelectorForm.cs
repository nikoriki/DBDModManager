﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace ModManagerDbd
{
    public partial class FolderSelectorForm : Form
    {
        private const string AppDataPath = "ModManagerDbd\\selectedPath.txt";
        private Label selectedPathLabel;

        public string SelectedPath { get; private set; }

        public FolderSelectorForm()
        {
            InitializeComponent();
            LoadSelectedPath();
        }

        private void InitializeComponent()
        {
            this.Text = "Select Folder";
            this.Size = new Size(400, 300);
            this.BackColor = ColorTranslator.FromHtml("#1a1b26");
            this.ForeColor = Color.White;
            this.FormBorderStyle = FormBorderStyle.None;
            this.StartPosition = FormStartPosition.CenterParent;

            Label titleLabel = new Label
            {
                Text = "Select the DeadByDaylight\\Content\\Paks folder",
                Font = new Font("Arial", 10, FontStyle.Regular),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(20, 20)
            };
            this.Controls.Add(titleLabel);

            Button selectButton = new Button
            {
                Text = "Select Folder",
                Font = new Font("Arial", 10, FontStyle.Regular),
                ForeColor = Color.White,
                BackColor = ColorTranslator.FromHtml("#1a1b26"),
                Width = 150,
                Height = 30,
                FlatStyle = FlatStyle.Flat,
                Location = new Point(20, 60)
            };
            selectButton.Click += SelectButton_Click;
            this.Controls.Add(selectButton);

            selectedPathLabel = new Label
            {
                Font = new Font("Arial", 10, FontStyle.Regular),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(180, 65)
            };
            this.Controls.Add(selectedPathLabel);

            Button okButton = new Button
            {
                Text = "OK",
                Font = new Font("Arial", 10, FontStyle.Regular),
                ForeColor = Color.White,
                BackColor = ColorTranslator.FromHtml("#1a1b26"),
                Width = 50,
                Height = 30,
                FlatStyle = FlatStyle.Flat,
                Location = new Point(200, 100)
            };
            okButton.Click += OkButton_Click;
            this.Controls.Add(okButton);

            Button cancelButton = new Button
            {
                Text = "Cancel",
                Font = new Font("Arial", 10, FontStyle.Regular),
                ForeColor = Color.White,
                BackColor = ColorTranslator.FromHtml("#1a1b26"),
                Width = 70,
                Height = 30,
                FlatStyle = FlatStyle.Flat,
                Location = new Point(260, 100)
            };
            cancelButton.Click += (sender, e) => this.DialogResult = DialogResult.Cancel;
            this.Controls.Add(cancelButton);
        }

        private void SelectButton_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog folderDialog = new FolderBrowserDialog())
            {
                folderDialog.Description = "Select the DeadByDaylight\\Content\\Paks folder";
                folderDialog.ShowNewFolderButton = false;

                if (folderDialog.ShowDialog() == DialogResult.OK)
                {
                    string selectedPath = folderDialog.SelectedPath;
                    if (!selectedPath.EndsWith("DeadByDaylight\\Content\\Paks"))
                    {
                        DialogResult result = MessageBox.Show("Are you sure this is the correct path?", "Confirm Path", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (result == DialogResult.No)
                        {
                            SelectButton_Click(sender, e);
                            return;
                        }
                    }

                    SelectedPath = selectedPath;
                    selectedPathLabel.Text = SelectedPath;
                    SaveSelectedPath();
                }
            }
        }

        private void OkButton_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(SelectedPath))
            {
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                MessageBox.Show("Please select a folder.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SaveSelectedPath()
        {
            string appDataFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ModManagerDbd");
            Directory.CreateDirectory(appDataFolder);
            File.WriteAllText(Path.Combine(appDataFolder, "selectedPath.txt"), SelectedPath);
        }

        private void LoadSelectedPath()
        {
            string appDataFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ModManagerDbd");
            string pathFile = Path.Combine(appDataFolder, "selectedPath.txt");

            if (File.Exists(pathFile))
            {
                SelectedPath = File.ReadAllText(pathFile);
                selectedPathLabel.Text = SelectedPath;
            }
        }
    }
}
