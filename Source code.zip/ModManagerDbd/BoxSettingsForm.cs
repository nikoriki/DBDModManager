﻿using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Xml.Linq;

namespace ModManagerDbd
{
    public partial class BoxSettingsForm : Form
    {
        public string BoxName { get; private set; }
        public string Description { get; private set; }
        public string SelectedFilePath { get; private set; }
        public string Version { get; private set; }

        public BoxSettingsForm(string initialName, string initialDescription, string initialVersion)
        {
            InitializeComponent();
            ApplyProfileManagerFormStyle();

            txtName.Text = initialName;
            txtDescription.Text = initialDescription;
            txtVersion.Text = initialVersion;
        }

        private void ApplyProfileManagerFormStyle()
        {
            this.BackColor = Color.LightGray; 
            this.Font = new Font("Arial", 10); 

            btnSelectFile.BackColor = Color.LightBlue;
            btnSelectFile.ForeColor = Color.Black;
            btnSave.BackColor = Color.LightGreen;
            btnSave.ForeColor = Color.Black;

            txtName.BackColor = Color.White;
            txtDescription.BackColor = Color.White;
            txtVersion.BackColor = Color.White;
            txtFilePath.BackColor = Color.White;
        }

        private void btnSelectFile_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Pakchunk files|pakchunk*.pak;pakchunk*.sig;pakchunk*.ucas;pakchunk*.utoc";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string selectedFile = openFileDialog.FileName;
                    if (IsValidPakchunkFile(selectedFile))
                    {
                        txtFilePath.Text = selectedFile;
                    }
                    else
                    {
                        MessageBox.Show("Invalid file selected. Please select a valid pakchunk file.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private bool IsValidPakchunkFile(string filePath)
        {
            string fileName = Path.GetFileName(filePath);
            string[] validExtensions = { ".pak", ".sig", ".ucas", ".utoc" };
            return fileName.StartsWith("pakchunk") && validExtensions.Contains(Path.GetExtension(fileName));
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            BoxName = txtName.Text;
            Description = txtDescription.Text;
            SelectedFilePath = txtFilePath.Text;
            Version = txtVersion.Text;
            DialogResult = DialogResult.OK;
            Close();
        }

        private void BoxSettingsForm_Load(object sender, EventArgs e)
        {

        }
    }
}
