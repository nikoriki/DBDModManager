﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace ModManagerDbd
{
    public partial class ProfileManagerForm : Form
    {
        public List<string> Profiles { get; private set; }
        public string DefaultProfile { get; private set; }
        private void LoadProfiles()
        {
            listBoxProfiles.Items.Clear();
            listBoxProfiles.Items.AddRange(Profiles.ToArray());
            if (!string.IsNullOrEmpty(DefaultProfile))
            {
                int index = Profiles.IndexOf(DefaultProfile);
                if (index >= 0)
                {
                    listBoxProfiles.SelectedIndex = index;
                    checkBoxDefaultProfile.Checked = true;
                }
            }
            UpdateCurrentProfileText();
        }

        private void UpdateCurrentProfileText()
        {
            if (listBoxProfiles.SelectedItem != null)
            {
                textBoxProfileName.Text = listBoxProfiles.SelectedItem.ToString();
            }
            else
            {
                textBoxProfileName.Clear();
            }
        }

        private void listBoxProfiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateCurrentProfileText();
        }

        public ProfileManagerForm(List<string> profiles, string defaultProfile)
        {
            InitializeComponent();
            Profiles = profiles;
            DefaultProfile = defaultProfile;
            LoadProfiles();
            CustomizeWindowControls();

            buttonAdd.Click += buttonAdd_Click;
            buttonRename.Click += buttonRename_Click;
            buttonDelete.Click += buttonDelete_Click;
            buttonOK.Click += buttonOK_Click;

            listBoxProfiles.SelectedIndexChanged += listBoxProfiles_SelectedIndexChanged;
        }



        private void buttonAdd_Click(object sender, EventArgs e)
        {
            string newProfile = textBoxProfileName.Text.Trim();
            if (!string.IsNullOrEmpty(newProfile) && !Profiles.Contains(newProfile))
            {
                Profiles.Add(newProfile);
                LoadProfiles();
            }
        }

        private void buttonRename_Click(object sender, EventArgs e)
        {
            if (listBoxProfiles.SelectedItem != null)
            {
                string selectedProfile = listBoxProfiles.SelectedItem.ToString();
                string newProfileName = textBoxProfileName.Text.Trim();
                if (!string.IsNullOrEmpty(newProfileName) && !Profiles.Contains(newProfileName))
                {
                    int index = Profiles.IndexOf(selectedProfile);
                    Profiles[index] = newProfileName;
                    LoadProfiles();
                }
            }
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (listBoxProfiles.SelectedItem != null)
            {
                string selectedProfile = listBoxProfiles.SelectedItem.ToString();
                Profiles.Remove(selectedProfile);
                if (selectedProfile == DefaultProfile)
                {
                    DefaultProfile = null;
                    checkBoxDefaultProfile.Checked = false;
                }
                LoadProfiles();
            }
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            if (checkBoxDefaultProfile.Checked && listBoxProfiles.SelectedItem != null)
            {
                DefaultProfile = listBoxProfiles.SelectedItem.ToString();
            }
            else
            {
                DefaultProfile = null;
            }
            DialogResult = DialogResult.OK;
            Close();
        }

        private void CustomizeWindowControls()
        {
            this.FormBorderStyle = FormBorderStyle.None;

            Panel titleBar = new Panel
            {
                Dock = DockStyle.Top,
                Height = 40,
                BackColor = ColorTranslator.FromHtml("#13141f")
            };
            this.Controls.Add(titleBar);

            Button minimizeButton = CreateButton("_", new Font("Arial", 12, FontStyle.Bold), Color.White, "#13141f", new Size(40, 30), new Point(this.Width - 90, 5));
            minimizeButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            minimizeButton.Click += (sender, e) => this.WindowState = FormWindowState.Minimized;
            titleBar.Controls.Add(minimizeButton);

            Button closeButton = CreateButton("X", new Font("Arial", 12, FontStyle.Bold), Color.White, "#13141f", new Size(40, 30), new Point(this.Width - 50, 5));
            closeButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            closeButton.Click += (sender, e) => this.Close();
            titleBar.Controls.Add(closeButton);

            titleBar.MouseDown += TitleBar_MouseDown;
            titleBar.MouseMove += TitleBar_MouseMove;
            titleBar.MouseUp += TitleBar_MouseUp;
        }

        private bool dragging = false;
        private Point dragCursorPoint;
        private Point dragFormPoint;

        private void TitleBar_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                dragging = true;
                dragCursorPoint = Cursor.Position;
                dragFormPoint = this.Location;
            }
        }

        private void TitleBar_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point diff = Point.Subtract(Cursor.Position, new Size(dragCursorPoint));
                this.Location = Point.Add(dragFormPoint, new Size(diff));
            }
        }

        private void TitleBar_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }
    }
}
