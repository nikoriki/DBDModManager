﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ModManagerDbd
{
    public partial class SettingsForm : Form
    {
        public SettingsForm()
        {
            InitializeComponent();
            SetupUI();
        }

        private void SetupUI()
        {
            this.Text = "Settings";
            this.Size = new Size(800, 600);
            this.BackColor = ColorTranslator.FromHtml("#1a1b26");
            this.ForeColor = Color.White;
            this.StartPosition = FormStartPosition.CenterScreen;

            Label settingsLabel = new Label
            {
                Text = "Settings",
                Font = new Font("Arial", 20, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(20, 20)
            };
            this.Controls.Add(settingsLabel);

            CheckBox modManagerAsMainScreenCheckBox = new CheckBox
            {
                Text = "Mod Manager as main screen",
                Font = new Font("Arial", 12, FontStyle.Regular),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(20, 60)
            };
            this.Controls.Add(modManagerAsMainScreenCheckBox);

            for (int i = 1; i <= 3; i++)
            {
                CheckBox placeholderCheckBox = new CheckBox
                {
                    Text = $"Placeholder Option {i}",
                    Font = new Font("Arial", 12, FontStyle.Regular),
                    ForeColor = Color.White,
                    AutoSize = true,
                    Location = new Point(20, 60 + (i * 30))
                };
                this.Controls.Add(placeholderCheckBox);
            }
        }
    }
}
