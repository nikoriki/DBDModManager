﻿namespace ModManagerDbd
{
    partial class ModFolderSelectorForm
    {

        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code


        private void InitializeComponent()
        {
            this.Text = "Select Mod Folder";
            this.Size = new System.Drawing.Size(400, 300);
            this.BackColor = System.Drawing.ColorTranslator.FromHtml("#1a1b26");
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;

            System.Windows.Forms.Label titleLabel = new System.Windows.Forms.Label
            {
                Text = "Select the folder where your mods are located",
                Font = new System.Drawing.Font("Arial", 10, System.Drawing.FontStyle.Regular),
                ForeColor = System.Drawing.Color.White,
                AutoSize = true,
                Location = new System.Drawing.Point(20, 20)
            };
            this.Controls.Add(titleLabel);

            System.Windows.Forms.Button selectButton = new System.Windows.Forms.Button
            {
                Text = "Select Folder",
                Font = new System.Drawing.Font("Arial", 10, System.Drawing.FontStyle.Regular),
                ForeColor = System.Drawing.Color.White,
                BackColor = System.Drawing.ColorTranslator.FromHtml("#1a1b26"),
                Width = 150,
                Height = 30,
                FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                Location = new System.Drawing.Point(20, 60)
            };
            selectButton.Click += SelectButton_Click;
            this.Controls.Add(selectButton);

            selectedPathLabel = new System.Windows.Forms.Label
            {
                Font = new System.Drawing.Font("Arial", 10, System.Drawing.FontStyle.Regular),
                ForeColor = System.Drawing.Color.White,
                AutoSize = true,
                Location = new System.Drawing.Point(180, 65)
            };
            this.Controls.Add(selectedPathLabel);

            System.Windows.Forms.Button okButton = new System.Windows.Forms.Button
            {
                Text = "OK",
                Font = new System.Drawing.Font("Arial", 10, System.Drawing.FontStyle.Regular),
                ForeColor = System.Drawing.Color.White,
                BackColor = System.Drawing.ColorTranslator.FromHtml("#1a1b26"),
                Width = 50,
                Height = 30,
                FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                Location = new System.Drawing.Point(200, 100)
            };
            okButton.Click += OkButton_Click;
            this.Controls.Add(okButton);

            System.Windows.Forms.Button cancelButton = new System.Windows.Forms.Button
            {
                Text = "Cancel",
                Font = new System.Drawing.Font("Arial", 10, System.Drawing.FontStyle.Regular),
                ForeColor = System.Drawing.Color.White,
                BackColor = System.Drawing.ColorTranslator.FromHtml("#1a1b26"),
                Width = 70,
                Height = 30,
                FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                Location = new System.Drawing.Point(260, 100)
            };
            cancelButton.Click += (sender, e) => this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Controls.Add(cancelButton);
        }

        #endregion
    }
}
