﻿using System.IO.Compression;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.WinForms;
using ZipFile = System.IO.Compression.ZipFile;
using System.IO.Compression;
using System.Reflection;





namespace ModManagerDbd
{
    public partial class MainForm : Form
    {
        private Panel sidebar;
        private Panel mainContent;
        private Panel modManagerContent;
        private Panel settingsContent;
        private Panel troubleshootContent;
        private Button toggleButton;
        private Timer sidebarAnimationTimer;
        private bool sidebarExpanded = false;
        private const int SidebarWidthExpanded = 150;
        private const int SidebarWidthCollapsed = 50;
        private Panel singleBox;
        private Panel smallBox;
        private Label headerLabel;
        private WebView2 dashboardWebView;
        private ComboBox noAnimationsComboBox;
        private ComboBox platformComboBox;

        private const string CurrentVersion = "Beta R.27.01";
        private const string BackgroundColor = "#1a1b26";
        private const string SidebarColor = "#13141f";
        private const string CardColor = "#1f2033";

        private bool dragging = false;
        private Point dragCursorPoint;
        private Point dragFormPoint;

        private const string SettingsFilePath = @"DBDModManager\settings.txt";
        private ComboBox modManagerAsMainScreenComboBox;
        private ComboBox[] placeholderComboBoxes;

        private ComboBox profileComboBox;
        private Button manageProfilesButton;
        private const string ProfilesFilePath = @"DBDModManager\profiles.txt";
        private Label currentProfileLabel;

        private Button removePaksButton;

        private List<Mod> mods;
        private TextBox filterTextBox;
        private ListBox modsListBox;
        private ListBox disabledModsListBox;

        private string selectedModFolderPath;
        private string selectedDbdPakFolderPath;
        private ListBox enabledModsListBox;
        private const string InstalledModsFilePath = @"DBDModManager\installedMods.txt";


        public MainForm()
        {
            InitializeComponent();
            InitializeUI();
            AddSettingsContentPanel();
            AddTroubleshootContent(); 
            AddModManagerContent();
            LoadSettings();
            LoadBoxContentAsync();
            CheckVersionAsync();
            LoadInstalledMods(); 
            LoadDisabledMods(disabledModsListBox);
        }




        private void InitializeUI()
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.Text = "DBD Mod Manager";
            this.Size = new Size(1200, 700);
            this.BackColor = ColorTranslator.FromHtml(BackgroundColor);
            this.ForeColor = Color.White;
            this.StartPosition = FormStartPosition.CenterScreen;

            AddCustomTitleBar();

            AddSidebar();

            mainContent = CreatePanel(DockStyle.Fill, new Padding(SidebarWidthCollapsed + 5, 60, 10, 20), BackgroundColor, true);
            this.Controls.Add(mainContent);

            modManagerContent = CreatePanel(DockStyle.Fill, new Padding(SidebarWidthCollapsed + 60, 60, 10, 20), BackgroundColor, false);
            this.Controls.Add(modManagerContent);

            troubleshootContent = CreatePanel(DockStyle.Fill, new Padding(SidebarWidthCollapsed + 60, 60, 10, 20), BackgroundColor, false);
            this.Controls.Add(troubleshootContent);

            AddSingleBox();

            sidebarAnimationTimer = new Timer
            {
                Interval = 10
            };
            sidebarAnimationTimer.Tick += AnimateSidebar;

            this.Resize += (sender, e) =>
            {
                AdjustSingleBox();
                AdjustContentPanels();
            };

            AddModManagerContent();
        }


        private async Task<string> FetchLatestVersionAsync()
        {
            string url = "http://s1037573399.mialojamiento.es/version.txt";
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.Timeout = TimeSpan.FromSeconds(30);
                    string version = await client.GetStringAsync(url);
                    return version.Trim();
                }
            }
            catch (TaskCanceledException)
            {
                return null;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error fetching version: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        private async void LoadBoxContentAsync()
        {
            string url = "http://s1037573399.mialojamiento.es/boxContent.txt";
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.Timeout = TimeSpan.FromSeconds(30);
                    string content = await client.GetStringAsync(url);
                    UpdateBoxContent(singleBox, content);
                }
            }
            catch (TaskCanceledException)
            {
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error fetching content: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateBoxContent(Panel box, string content)
        {
            if (box != null)
            {
                string[] lines = content.Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
                string title = lines.Length > 0 ? lines[0] : string.Empty;
                string message = lines.Length > 1 ? string.Join("\n", lines.Skip(1)) : string.Empty;

                foreach (Control control in box.Controls)
                {
                    if (control is Label label && label.Font.Style == FontStyle.Bold)
                    {
                        label.Text = title;
                    }
                    else if (control is Label labelContent)
                    {
                        labelContent.Text = message;
                    }
                }
            }
        }

        private Panel CreateCard(string title, string content, int x, int y, int width, int height = 400)
        {
            Panel card = new Panel
            {
                Location = new Point(x, y),
                Size = new Size(width, height),
                BackColor = ColorTranslator.FromHtml(CardColor),
                BorderStyle = BorderStyle.FixedSingle
            };

            Label cardTitle = CreateLabel(title, new Font("Arial", 12, FontStyle.Bold), Color.White, new Point(10, 10));
            card.Controls.Add(cardTitle);

            Label cardContent = CreateLabel(content, new Font("Arial", 10, FontStyle.Regular), Color.Gray, new Point(10, 40));
            cardContent.Size = new Size(card.Width - 20, card.Height - 50);
            cardContent.AutoSize = false;
            cardContent.MaximumSize = new Size(card.Width - 20, 0);
            cardContent.AutoSize = true;
            card.Controls.Add(cardContent);

            return card;
        }
        private async void LoadSmallBoxContentAsync(Panel smallBox)
        {
            string url = "http://s1037573399.mialojamiento.es/boxContent2.txt";
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.Timeout = TimeSpan.FromSeconds(30);
                    string content = await client.GetStringAsync(url);
                    UpdateBoxContent(smallBox, content);
                }
            }
            catch (TaskCanceledException)
            {
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error fetching content: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void PlatformComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            SaveSettings();
        }

        private async void CheckVersionAsync()
        {
            string latestVersion = await FetchLatestVersionAsync();
            if (latestVersion != null && latestVersion != CurrentVersion)
            {
                versionLabel.ForeColor = Color.Red;
                versionLabel.Text = $"Version {CurrentVersion} [OUTDATED]";
            }
            else
            {
                versionLabel.ForeColor = Color.Gray;
                versionLabel.Text = $"Version {CurrentVersion}";
            }
        }

        private void AddTroubleshootContent()
        {
            troubleshootContent.Controls.Clear();

            removePaksButton = new Button
            {
                Text = "Remove ALL modified .paks",
                Font = new Font("Arial", 10, FontStyle.Regular),
                ForeColor = Color.White,
                BackColor = ColorTranslator.FromHtml("#1a1b26"),
                Width = 200,
                Height = 25,
                FlatStyle = FlatStyle.Flat,
                Location = new Point(SidebarWidthCollapsed + 10, 100)
            };
            removePaksButton.Click += RemovePaksButton_Click;
            troubleshootContent.Controls.Add(removePaksButton);
        }

        private void RemovePaksButton_Click(object sender, EventArgs e)
        {
            string platformCode = null;
            if (platformComboBox.SelectedItem != null)
            {
                switch (platformComboBox.SelectedItem.ToString())
                {
                    case "Epic Games":
                        platformCode = "EGS";
                        break;
                    case "Steam":
                        platformCode = "Windows";
                        break;
                    case "Microsoft Store":
                        platformCode = "WinGDK";
                        break;
                }
            }

            if (platformCode == null)
            {
                MessageBox.Show("Please select a platform first.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DialogResult result = MessageBox.Show(
                "Are you sure? This will delete ALL modified .pak files FROM the selected platform, so if the platform chosen is Epic Games, it will delete EVERY single .pak file that DOESN'T come with the default game from Epic Games and DOESN'T have EGS in the name.",
                "Confirm Deletion",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (result == DialogResult.No)
            {
                return;
            }

            string[] requiredFiles = new string[]
            {
        "global.ucas", "global.utoc",
        $"pakchunk0-{platformCode}.pak", $"pakchunk0-{platformCode}.sig", $"pakchunk0-{platformCode}.ucas", $"pakchunk0-{platformCode}.utoc",
        $"pakchunk1-{platformCode}.pak", $"pakchunk1-{platformCode}.sig", $"pakchunk1-{platformCode}.ucas", $"pakchunk1-{platformCode}.utoc",
        $"pakchunk10-{platformCode}.pak", $"pakchunk10-{platformCode}.sig", $"pakchunk10-{platformCode}.ucas", $"pakchunk10-{platformCode}.utoc",
        $"pakchunk1002-{platformCode}.pak", $"pakchunk1002-{platformCode}.sig", $"pakchunk1002-{platformCode}.ucas", $"pakchunk1002-{platformCode}.utoc",
        $"pakchunk1004-{platformCode}.pak", $"pakchunk1004-{platformCode}.sig", $"pakchunk1004-{platformCode}.ucas", $"pakchunk1004-{platformCode}.utoc",
        $"pakchunk1006-{platformCode}.pak", $"pakchunk1006-{platformCode}.sig", $"pakchunk1006-{platformCode}.ucas", $"pakchunk1006-{platformCode}.utoc",
        $"pakchunk1007-{platformCode}.pak", $"pakchunk1007-{platformCode}.sig", $"pakchunk1007-{platformCode}.ucas", $"pakchunk1007-{platformCode}.utoc",
        $"pakchunk1008-{platformCode}.pak", $"pakchunk1008-{platformCode}.sig", $"pakchunk1008-{platformCode}.ucas", $"pakchunk1008-{platformCode}.utoc",
        $"pakchunk1009-{platformCode}.pak", $"pakchunk1009-{platformCode}.sig", $"pakchunk1009-{platformCode}.ucas", $"pakchunk1009-{platformCode}.utoc",
        $"pakchunk1010-{platformCode}.pak", $"pakchunk1010-{platformCode}.sig", $"pakchunk1010-{platformCode}.ucas", $"pakchunk1010-{platformCode}.utoc",
        $"pakchunk1011-{platformCode}.pak", $"pakchunk1011-{platformCode}.sig", $"pakchunk1011-{platformCode}.ucas", $"pakchunk1011-{platformCode}.utoc",
        $"pakchunk1014-{platformCode}.pak", $"pakchunk1014-{platformCode}.sig", $"pakchunk1014-{platformCode}.ucas", $"pakchunk1014-{platformCode}.utoc",
        $"pakchunk1015-{platformCode}.pak", $"pakchunk1015-{platformCode}.sig", $"pakchunk1015-{platformCode}.ucas", $"pakchunk1015-{platformCode}.utoc",
        $"pakchunk1016-{platformCode}.pak", $"pakchunk1016-{platformCode}.sig", $"pakchunk1016-{platformCode}.ucas", $"pakchunk1016-{platformCode}.utoc",
        $"pakchunk1017-{platformCode}.pak", $"pakchunk1017-{platformCode}.sig", $"pakchunk1017-{platformCode}.ucas", $"pakchunk1017-{platformCode}.utoc",
        $"pakchunk1018-{platformCode}.pak", $"pakchunk1018-{platformCode}.sig", $"pakchunk1018-{platformCode}.ucas", $"pakchunk1018-{platformCode}.utoc",
        $"pakchunk1020-{platformCode}.pak", $"pakchunk1020-{platformCode}.sig", $"pakchunk1020-{platformCode}.ucas", $"pakchunk1020-{platformCode}.utoc",
        $"pakchunk1024-{platformCode}.pak", $"pakchunk1024-{platformCode}.sig", $"pakchunk1024-{platformCode}.ucas", $"pakchunk1024-{platformCode}.utoc",
        $"pakchunk1025-{platformCode}.pak", $"pakchunk1025-{platformCode}.sig", $"pakchunk1025-{platformCode}.ucas", $"pakchunk1025-{platformCode}.utoc",
        $"pakchunk1027-{platformCode}.pak", $"pakchunk1027-{platformCode}.sig", $"pakchunk1027-{platformCode}.ucas", $"pakchunk1027-{platformCode}.utoc",
        $"pakchunk1029-{platformCode}.pak", $"pakchunk1029-{platformCode}.sig", $"pakchunk1029-{platformCode}.ucas", $"pakchunk1029-{platformCode}.utoc",
        $"pakchunk1033-{platformCode}.pak", $"pakchunk1033-{platformCode}.sig", $"pakchunk1033-{platformCode}.ucas", $"pakchunk1033-{platformCode}.utoc",
        $"pakchunk1034-{platformCode}.pak", $"pakchunk1034-{platformCode}.sig", $"pakchunk1034-{platformCode}.ucas", $"pakchunk1034-{platformCode}.utoc",
        $"pakchunk1036-{platformCode}.pak", $"pakchunk1036-{platformCode}.sig", $"pakchunk1036-{platformCode}.ucas", $"pakchunk1036-{platformCode}.utoc",
        $"pakchunk1037-{platformCode}.pak", $"pakchunk1037-{platformCode}.sig", $"pakchunk1037-{platformCode}.ucas", $"pakchunk1037-{platformCode}.utoc",
        $"pakchunk1038-{platformCode}.pak", $"pakchunk1038-{platformCode}.sig", $"pakchunk1038-{platformCode}.ucas", $"pakchunk1038-{platformCode}.utoc",
        $"pakchunk11-{platformCode}.pak", $"pakchunk11-{platformCode}.sig", $"pakchunk11-{platformCode}.ucas", $"pakchunk11-{platformCode}.utoc",
        $"pakchunk12-{platformCode}.pak", $"pakchunk12-{platformCode}.sig", $"pakchunk12-{platformCode}.ucas", $"pakchunk12-{platformCode}.utoc",
        $"pakchunk13-{platformCode}.pak", $"pakchunk13-{platformCode}.sig", $"pakchunk13-{platformCode}.ucas", $"pakchunk13-{platformCode}.utoc",
        $"pakchunk14-{platformCode}.pak", $"pakchunk14-{platformCode}.sig", $"pakchunk14-{platformCode}.ucas", $"pakchunk14-{platformCode}.utoc",
        $"pakchunk15-{platformCode}.pak", $"pakchunk15-{platformCode}.sig", $"pakchunk15-{platformCode}.ucas", $"pakchunk15-{platformCode}.utoc",
        $"pakchunk1511-{platformCode}.pak", $"pakchunk1511-{platformCode}.sig", $"pakchunk1511-{platformCode}.ucas", $"pakchunk1511-{platformCode}.utoc",
        $"pakchunk1512-{platformCode}.pak", $"pakchunk1512-{platformCode}.sig", $"pakchunk1512-{platformCode}.ucas", $"pakchunk1512-{platformCode}.utoc",
        $"pakchunk1517-{platformCode}.pak", $"pakchunk1517-{platformCode}.sig", $"pakchunk1517-{platformCode}.ucas", $"pakchunk1517-{platformCode}.utoc",
        $"pakchunk1518-{platformCode}.pak", $"pakchunk1518-{platformCode}.sig", $"pakchunk1518-{platformCode}.ucas", $"pakchunk1518-{platformCode}.utoc",
        $"pakchunk1519-{platformCode}.pak", $"pakchunk1519-{platformCode}.sig", $"pakchunk1519-{platformCode}.ucas", $"pakchunk1519-{platformCode}.utoc",
        $"pakchunk1526-{platformCode}.pak", $"pakchunk1526-{platformCode}.sig", $"pakchunk1526-{platformCode}.ucas", $"pakchunk1526-{platformCode}.utoc",
        $"pakchunk1527-{platformCode}.pak", $"pakchunk1527-{platformCode}.sig", $"pakchunk1527-{platformCode}.ucas", $"pakchunk1527-{platformCode}.utoc",
        $"pakchunk1530-{platformCode}.pak", $"pakchunk1530-{platformCode}.sig", $"pakchunk1530-{platformCode}.ucas", $"pakchunk1530-{platformCode}.utoc",
        $"pakchunk1532-{platformCode}.pak", $"pakchunk1532-{platformCode}.sig", $"pakchunk1532-{platformCode}.ucas", $"pakchunk1532-{platformCode}.utoc",
        $"pakchunk1533-{platformCode}.pak", $"pakchunk1533-{platformCode}.sig", $"pakchunk1533-{platformCode}.ucas", $"pakchunk1533-{platformCode}.utoc",
        $"pakchunk1538-{platformCode}.pak", $"pakchunk1538-{platformCode}.sig", $"pakchunk1538-{platformCode}.ucas", $"pakchunk1538-{platformCode}.utoc",
        $"pakchunk1539-{platformCode}.pak", $"pakchunk1539-{platformCode}.sig", $"pakchunk1539-{platformCode}.ucas", $"pakchunk1539-{platformCode}.utoc",
        $"pakchunk1540-{platformCode}.pak", $"pakchunk1540-{platformCode}.sig", $"pakchunk1540-{platformCode}.ucas", $"pakchunk1540-{platformCode}.utoc",
        $"pakchunk1542-{platformCode}.pak", $"pakchunk1542-{platformCode}.sig", $"pakchunk1542-{platformCode}.ucas", $"pakchunk1542-{platformCode}.utoc",
        $"pakchunk1543-{platformCode}.pak", $"pakchunk1543-{platformCode}.sig", $"pakchunk1543-{platformCode}.ucas", $"pakchunk1543-{platformCode}.utoc",
        $"pakchunk1544-{platformCode}.pak", $"pakchunk1544-{platformCode}.sig", $"pakchunk1544-{platformCode}.ucas", $"pakchunk1544-{platformCode}.utoc",
        $"pakchunk1545-{platformCode}.pak", $"pakchunk1545-{platformCode}.sig", $"pakchunk1545-{platformCode}.ucas", $"pakchunk1545-{platformCode}.utoc",
        $"pakchunk16-{platformCode}.pak", $"pakchunk16-{platformCode}.sig", $"pakchunk16-{platformCode}.ucas", $"pakchunk16-{platformCode}.utoc",
        $"pakchunk17-{platformCode}.pak", $"pakchunk17-{platformCode}.sig", $"pakchunk17-{platformCode}.ucas", $"pakchunk17-{platformCode}.utoc",
        $"pakchunk18-{platformCode}.pak", $"pakchunk18-{platformCode}.sig", $"pakchunk18-{platformCode}.ucas", $"pakchunk18-{platformCode}.utoc",
        $"pakchunk19-{platformCode}.pak", $"pakchunk19-{platformCode}.sig", $"pakchunk19-{platformCode}.ucas", $"pakchunk19-{platformCode}.utoc",
        $"pakchunk2-{platformCode}.pak", $"pakchunk2-{platformCode}.sig", $"pakchunk2-{platformCode}.ucas", $"pakchunk2-{platformCode}.utoc",
        $"pakchunk20-{platformCode}.pak", $"pakchunk20-{platformCode}.sig", $"pakchunk20-{platformCode}.ucas", $"pakchunk20-{platformCode}.utoc",
        $"pakchunk2000-{platformCode}.pak", $"pakchunk2000-{platformCode}.sig", $"pakchunk2000-{platformCode}.ucas", $"pakchunk2000-{platformCode}.utoc",
        $"pakchunk2001-{platformCode}.pak", $"pakchunk2001-{platformCode}.sig", $"pakchunk2001-{platformCode}.ucas", $"pakchunk2001-{platformCode}.utoc",
        $"pakchunk2003-{platformCode}.pak", $"pakchunk2003-{platformCode}.sig", $"pakchunk2003-{platformCode}.ucas", $"pakchunk2003-{platformCode}.utoc",
        $"pakchunk2006-{platformCode}.pak", $"pakchunk2006-{platformCode}.sig", $"pakchunk2006-{platformCode}.ucas", $"pakchunk2006-{platformCode}.utoc",
        $"pakchunk2007-{platformCode}.pak", $"pakchunk2007-{platformCode}.sig", $"pakchunk2007-{platformCode}.ucas", $"pakchunk2007-{platformCode}.utoc",
        $"pakchunk2008-{platformCode}.pak", $"pakchunk2008-{platformCode}.sig", $"pakchunk2008-{platformCode}.ucas", $"pakchunk2008-{platformCode}.utoc",
        $"pakchunk2010-{platformCode}.pak", $"pakchunk2010-{platformCode}.sig", $"pakchunk2010-{platformCode}.ucas", $"pakchunk2010-{platformCode}.utoc",
        $"pakchunk2011-{platformCode}.pak", $"pakchunk2011-{platformCode}.sig", $"pakchunk2011-{platformCode}.ucas", $"pakchunk2011-{platformCode}.utoc",
        $"pakchunk2012-{platformCode}.pak", $"pakchunk2012-{platformCode}.sig", $"pakchunk2012-{platformCode}.ucas", $"pakchunk2012-{platformCode}.utoc",
        $"pakchunk2016-{platformCode}.pak", $"pakchunk2016-{platformCode}.sig", $"pakchunk2016-{platformCode}.ucas", $"pakchunk2016-{platformCode}.utoc",
        $"pakchunk2017-{platformCode}.pak", $"pakchunk2017-{platformCode}.sig", $"pakchunk2017-{platformCode}.ucas", $"pakchunk2017-{platformCode}.utoc",
        $"pakchunk2018-{platformCode}.pak", $"pakchunk2018-{platformCode}.sig", $"pakchunk2018-{platformCode}.ucas", $"pakchunk2018-{platformCode}.utoc",
        $"pakchunk2019-{platformCode}.pak", $"pakchunk2019-{platformCode}.sig", $"pakchunk2019-{platformCode}.ucas", $"pakchunk2019-{platformCode}.utoc",
        $"pakchunk2020-{platformCode}.pak", $"pakchunk2020-{platformCode}.sig", $"pakchunk2020-{platformCode}.ucas", $"pakchunk2020-{platformCode}.utoc",
        $"pakchunk2021-{platformCode}.pak", $"pakchunk2021-{platformCode}.sig", $"pakchunk2021-{platformCode}.ucas", $"pakchunk2021-{platformCode}.utoc",
        $"pakchunk2022-{platformCode}.pak", $"pakchunk2022-{platformCode}.sig", $"pakchunk2022-{platformCode}.ucas", $"pakchunk2022-{platformCode}.utoc",
        $"pakchunk2023-{platformCode}.pak", $"pakchunk2023-{platformCode}.sig", $"pakchunk2023-{platformCode}.ucas", $"pakchunk2023-{platformCode}.utoc",
        $"pakchunk2024-{platformCode}.pak", $"pakchunk2024-{platformCode}.sig", $"pakchunk2024-{platformCode}.ucas", $"pakchunk2024-{platformCode}.utoc",
        $"pakchunk2025-{platformCode}.pak", $"pakchunk2025-{platformCode}.sig", $"pakchunk2025-{platformCode}.ucas", $"pakchunk2025-{platformCode}.utoc",
        $"pakchunk2026-{platformCode}.pak", $"pakchunk2026-{platformCode}.sig", $"pakchunk2026-{platformCode}.ucas", $"pakchunk2026-{platformCode}.utoc",
        $"pakchunk2027-{platformCode}.pak", $"pakchunk2027-{platformCode}.sig", $"pakchunk2027-{platformCode}.ucas", $"pakchunk2027-{platformCode}.utoc",
        $"pakchunk2028-{platformCode}.pak", $"pakchunk2028-{platformCode}.sig", $"pakchunk2028-{platformCode}.ucas", $"pakchunk2028-{platformCode}.utoc",
        $"pakchunk2029-{platformCode}.pak", $"pakchunk2029-{platformCode}.sig", $"pakchunk2029-{platformCode}.ucas", $"pakchunk2029-{platformCode}.utoc",
        $"pakchunk2030-{platformCode}.pak", $"pakchunk2030-{platformCode}.sig", $"pakchunk2030-{platformCode}.ucas", $"pakchunk2030-{platformCode}.utoc",
        $"pakchunk2031-{platformCode}.pak", $"pakchunk2031-{platformCode}.sig", $"pakchunk2031-{platformCode}.ucas", $"pakchunk2031-{platformCode}.utoc",
        $"pakchunk2032-{platformCode}.pak", $"pakchunk2032-{platformCode}.sig", $"pakchunk2032-{platformCode}.ucas", $"pakchunk2032-{platformCode}.utoc",
        $"pakchunk2033-{platformCode}.pak", $"pakchunk2033-{platformCode}.sig", $"pakchunk2033-{platformCode}.ucas", $"pakchunk2033-{platformCode}.utoc",
        $"pakchunk2034-{platformCode}.pak", $"pakchunk2034-{platformCode}.sig", $"pakchunk2034-{platformCode}.ucas", $"pakchunk2034-{platformCode}.utoc",
        $"pakchunk2035-{platformCode}.pak", $"pakchunk2035-{platformCode}.sig", $"pakchunk2035-{platformCode}.ucas", $"pakchunk2035-{platformCode}.utoc",
        $"pakchunk2036-{platformCode}.pak", $"pakchunk2036-{platformCode}.sig", $"pakchunk2036-{platformCode}.ucas", $"pakchunk2036-{platformCode}.utoc",
        $"pakchunk2037-{platformCode}.pak", $"pakchunk2037-{platformCode}.sig", $"pakchunk2037-{platformCode}.ucas", $"pakchunk2037-{platformCode}.utoc",
        $"pakchunk2038-{platformCode}.pak", $"pakchunk2038-{platformCode}.sig", $"pakchunk2038-{platformCode}.ucas", $"pakchunk2038-{platformCode}.utoc",
        $"pakchunk2039-{platformCode}.pak", $"pakchunk2039-{platformCode}.sig", $"pakchunk2039-{platformCode}.ucas", $"pakchunk2039-{platformCode}.utoc",
        $"pakchunk2040-{platformCode}.pak", $"pakchunk2040-{platformCode}.sig", $"pakchunk2040-{platformCode}.ucas", $"pakchunk2040-{platformCode}.utoc",
        $"pakchunk2041-{platformCode}.pak", $"pakchunk2041-{platformCode}.sig", $"pakchunk2041-{platformCode}.ucas", $"pakchunk2041-{platformCode}.utoc",
        $"pakchunk2042-{platformCode}.pak", $"pakchunk2042-{platformCode}.sig", $"pakchunk2042-{platformCode}.ucas", $"pakchunk2042-{platformCode}.utoc",
        $"pakchunk2043-{platformCode}.pak", $"pakchunk2043-{platformCode}.sig", $"pakchunk2043-{platformCode}.ucas", $"pakchunk2043-{platformCode}.utoc",
        $"pakchunk2044-{platformCode}.pak", $"pakchunk2044-{platformCode}.sig", $"pakchunk2044-{platformCode}.ucas", $"pakchunk2044-{platformCode}.utoc",
        $"pakchunk2045-{platformCode}.pak", $"pakchunk2045-{platformCode}.sig", $"pakchunk2045-{platformCode}.ucas", $"pakchunk2045-{platformCode}.utoc",
        $"pakchunk2046-{platformCode}.pak", $"pakchunk2046-{platformCode}.sig", $"pakchunk2046-{platformCode}.ucas", $"pakchunk2046-{platformCode}.utoc",
        $"pakchunk2047-{platformCode}.pak", $"pakchunk2047-{platformCode}.sig", $"pakchunk2047-{platformCode}.ucas", $"pakchunk2047-{platformCode}.utoc",
        $"pakchunk2048-{platformCode}.pak", $"pakchunk2048-{platformCode}.sig", $"pakchunk2048-{platformCode}.ucas", $"pakchunk2048-{platformCode}.utoc",
        $"pakchunk2049-{platformCode}.pak", $"pakchunk2049-{platformCode}.sig", $"pakchunk2049-{platformCode}.ucas", $"pakchunk2049-{platformCode}.utoc",
        $"pakchunk2050-{platformCode}.pak", $"pakchunk2050-{platformCode}.sig", $"pakchunk2050-{platformCode}.ucas", $"pakchunk2050-{platformCode}.utoc",
        $"pakchunk2051-{platformCode}.pak", $"pakchunk2051-{platformCode}.sig", $"pakchunk2051-{platformCode}.ucas", $"pakchunk2051-{platformCode}.utoc",
        $"pakchunk2052-{platformCode}.pak", $"pakchunk2052-{platformCode}.sig", $"pakchunk2052-{platformCode}.ucas", $"pakchunk2052-{platformCode}.utoc",
        $"pakchunk2053-{platformCode}.pak", $"pakchunk2053-{platformCode}.sig", $"pakchunk2053-{platformCode}.ucas", $"pakchunk2053-{platformCode}.utoc",
        $"pakchunk2054-{platformCode}.pak", $"pakchunk2054-{platformCode}.sig", $"pakchunk2054-{platformCode}.ucas", $"pakchunk2054-{platformCode}.utoc",
        $"pakchunk2055-{platformCode}.pak", $"pakchunk2055-{platformCode}.sig", $"pakchunk2055-{platformCode}.ucas", $"pakchunk2055-{platformCode}.utoc",
        $"pakchunk2056-{platformCode}.pak", $"pakchunk2056-{platformCode}.sig", $"pakchunk2056-{platformCode}.ucas", $"pakchunk2056-{platformCode}.utoc",
        $"pakchunk2057-{platformCode}.pak", $"pakchunk2057-{platformCode}.sig", $"pakchunk2057-{platformCode}.ucas", $"pakchunk2057-{platformCode}.utoc",
        $"pakchunk2058-{platformCode}.pak", $"pakchunk2058-{platformCode}.sig", $"pakchunk2058-{platformCode}.ucas", $"pakchunk2058-{platformCode}.utoc",
        $"pakchunk2059-{platformCode}.pak", $"pakchunk2059-{platformCode}.sig", $"pakchunk2059-{platformCode}.ucas", $"pakchunk2059-{platformCode}.utoc",
        $"pakchunk2060-{platformCode}.pak", $"pakchunk2060-{platformCode}.sig", $"pakchunk2060-{platformCode}.ucas", $"pakchunk2060-{platformCode}.utoc",
        $"pakchunk2061-{platformCode}.pak", $"pakchunk2061-{platformCode}.sig", $"pakchunk2061-{platformCode}.ucas", $"pakchunk2061-{platformCode}.utoc",
        $"pakchunk2062-{platformCode}.pak", $"pakchunk2062-{platformCode}.sig", $"pakchunk2062-{platformCode}.ucas", $"pakchunk2062-{platformCode}.utoc",
        $"pakchunk21-{platformCode}.pak", $"pakchunk21-{platformCode}.sig", $"pakchunk21-{platformCode}.ucas", $"pakchunk21-{platformCode}.utoc",
        $"pakchunk22-{platformCode}.pak", $"pakchunk22-{platformCode}.sig", $"pakchunk22-{platformCode}.ucas", $"pakchunk22-{platformCode}.utoc",
        $"pakchunk2800-{platformCode}.pak", $"pakchunk2800-{platformCode}.sig", $"pakchunk2800-{platformCode}.ucas", $"pakchunk2800-{platformCode}.utoc",
        $"pakchunk2801-{platformCode}.pak", $"pakchunk2801-{platformCode}.sig", $"pakchunk2801-{platformCode}.ucas", $"pakchunk2801-{platformCode}.utoc",
        $"pakchunk3-{platformCode}.pak", $"pakchunk3-{platformCode}.sig", $"pakchunk3-{platformCode}.ucas", $"pakchunk3-{platformCode}.utoc",
        $"pakchunk3000-{platformCode}.pak", $"pakchunk3000-{platformCode}.sig", $"pakchunk3000-{platformCode}.ucas", $"pakchunk3000-{platformCode}.utoc",
        $"pakchunk3004-{platformCode}.pak", $"pakchunk3004-{platformCode}.sig", $"pakchunk3004-{platformCode}.ucas", $"pakchunk3004-{platformCode}.utoc",
        $"pakchunk3005-{platformCode}.pak", $"pakchunk3005-{platformCode}.sig", $"pakchunk3005-{platformCode}.ucas", $"pakchunk3005-{platformCode}.utoc",
        $"pakchunk3006-{platformCode}.pak", $"pakchunk3006-{platformCode}.sig", $"pakchunk3006-{platformCode}.ucas", $"pakchunk3006-{platformCode}.utoc",
        $"pakchunk3009-{platformCode}.pak", $"pakchunk3009-{platformCode}.sig", $"pakchunk3009-{platformCode}.ucas", $"pakchunk3009-{platformCode}.utoc",
        $"pakchunk3010-{platformCode}.pak", $"pakchunk3010-{platformCode}.sig", $"pakchunk3010-{platformCode}.ucas", $"pakchunk3010-{platformCode}.utoc",
        $"pakchunk3011-{platformCode}.pak", $"pakchunk3011-{platformCode}.sig", $"pakchunk3011-{platformCode}.ucas", $"pakchunk3011-{platformCode}.utoc",
        $"pakchunk3014-{platformCode}.pak", $"pakchunk3014-{platformCode}.sig", $"pakchunk3014-{platformCode}.ucas", $"pakchunk3014-{platformCode}.utoc",
        $"pakchunk3023-{platformCode}.pak", $"pakchunk3023-{platformCode}.sig", $"pakchunk3023-{platformCode}.ucas", $"pakchunk3023-{platformCode}.utoc",
        $"pakchunk3024-{platformCode}.pak", $"pakchunk3024-{platformCode}.sig", $"pakchunk3024-{platformCode}.ucas", $"pakchunk3024-{platformCode}.utoc",
        $"pakchunk3026-{platformCode}.pak", $"pakchunk3026-{platformCode}.sig", $"pakchunk3026-{platformCode}.ucas", $"pakchunk3026-{platformCode}.utoc",
        $"pakchunk3027-{platformCode}.pak", $"pakchunk3027-{platformCode}.sig", $"pakchunk3027-{platformCode}.ucas", $"pakchunk3027-{platformCode}.utoc",
        $"pakchunk3029-{platformCode}.pak", $"pakchunk3029-{platformCode}.sig", $"pakchunk3029-{platformCode}.ucas", $"pakchunk3029-{platformCode}.utoc",
        $"pakchunk3030-{platformCode}.pak", $"pakchunk3030-{platformCode}.sig", $"pakchunk3030-{platformCode}.ucas", $"pakchunk3030-{platformCode}.utoc",
        $"pakchunk3031-{platformCode}.pak", $"pakchunk3031-{platformCode}.sig", $"pakchunk3031-{platformCode}.ucas", $"pakchunk3031-{platformCode}.utoc",
        $"pakchunk3032-{platformCode}.pak", $"pakchunk3032-{platformCode}.sig", $"pakchunk3032-{platformCode}.ucas", $"pakchunk3032-{platformCode}.utoc",
        $"pakchunk3033-{platformCode}.pak", $"pakchunk3033-{platformCode}.sig", $"pakchunk3033-{platformCode}.ucas", $"pakchunk3033-{platformCode}.utoc",
        $"pakchunk3034-{platformCode}.pak", $"pakchunk3034-{platformCode}.sig", $"pakchunk3034-{platformCode}.ucas", $"pakchunk3034-{platformCode}.utoc",
        $"pakchunk3035-{platformCode}.pak", $"pakchunk3035-{platformCode}.sig", $"pakchunk3035-{platformCode}.ucas", $"pakchunk3035-{platformCode}.utoc",
        $"pakchunk3036-{platformCode}.pak", $"pakchunk3036-{platformCode}.sig", $"pakchunk3036-{platformCode}.ucas", $"pakchunk3036-{platformCode}.utoc",
        $"pakchunk3037-{platformCode}.pak", $"pakchunk3037-{platformCode}.sig", $"pakchunk3037-{platformCode}.ucas", $"pakchunk3037-{platformCode}.utoc",
        $"pakchunk3038-{platformCode}.pak", $"pakchunk3038-{platformCode}.sig", $"pakchunk3038-{platformCode}.ucas", $"pakchunk3038-{platformCode}.utoc",
        $"pakchunk3039-{platformCode}.pak", $"pakchunk3039-{platformCode}.sig", $"pakchunk3039-{platformCode}.ucas", $"pakchunk3039-{platformCode}.utoc",
        $"pakchunk3041-{platformCode}.pak", $"pakchunk3041-{platformCode}.sig", $"pakchunk3041-{platformCode}.ucas", $"pakchunk3041-{platformCode}.utoc",
        $"pakchunk3042-{platformCode}.pak", $"pakchunk3042-{platformCode}.sig", $"pakchunk3042-{platformCode}.ucas", $"pakchunk3042-{platformCode}.utoc",
        $"pakchunk3043-{platformCode}.pak", $"pakchunk3043-{platformCode}.sig", $"pakchunk3043-{platformCode}.ucas", $"pakchunk3043-{platformCode}.utoc",
        $"pakchunk3044-{platformCode}.pak", $"pakchunk3044-{platformCode}.sig", $"pakchunk3044-{platformCode}.ucas", $"pakchunk3044-{platformCode}.utoc",
        $"pakchunk3045-{platformCode}.pak", $"pakchunk3045-{platformCode}.sig", $"pakchunk3045-{platformCode}.ucas", $"pakchunk3045-{platformCode}.utoc",
        $"pakchunk3048-{platformCode}.pak", $"pakchunk3048-{platformCode}.sig", $"pakchunk3048-{platformCode}.ucas", $"pakchunk3048-{platformCode}.utoc",
        $"pakchunk3049-{platformCode}.pak", $"pakchunk3049-{platformCode}.sig", $"pakchunk3049-{platformCode}.ucas", $"pakchunk3049-{platformCode}.utoc",
        $"pakchunk3053-{platformCode}.pak", $"pakchunk3053-{platformCode}.sig", $"pakchunk3053-{platformCode}.ucas", $"pakchunk3053-{platformCode}.utoc",
        $"pakchunk3054-{platformCode}.pak", $"pakchunk3054-{platformCode}.sig", $"pakchunk3054-{platformCode}.ucas", $"pakchunk3054-{platformCode}.utoc",
        $"pakchunk3055-{platformCode}.pak", $"pakchunk3055-{platformCode}.sig", $"pakchunk3055-{platformCode}.ucas", $"pakchunk3055-{platformCode}.utoc",
        $"pakchunk3056-{platformCode}.pak", $"pakchunk3056-{platformCode}.sig", $"pakchunk3056-{platformCode}.ucas", $"pakchunk3056-{platformCode}.utoc",
        $"pakchunk3060-{platformCode}.pak", $"pakchunk3060-{platformCode}.sig", $"pakchunk3060-{platformCode}.ucas", $"pakchunk3060-{platformCode}.utoc",
        $"pakchunk3061-{platformCode}.pak", $"pakchunk3061-{platformCode}.sig", $"pakchunk3061-{platformCode}.ucas", $"pakchunk3061-{platformCode}.utoc",
        $"pakchunk3062-{platformCode}.pak", $"pakchunk3062-{platformCode}.sig", $"pakchunk3062-{platformCode}.ucas", $"pakchunk3062-{platformCode}.utoc",
        $"pakchunk3063-{platformCode}.pak", $"pakchunk3063-{platformCode}.sig", $"pakchunk3063-{platformCode}.ucas", $"pakchunk3063-{platformCode}.utoc",
        $"pakchunk3064-{platformCode}.pak", $"pakchunk3064-{platformCode}.sig", $"pakchunk3064-{platformCode}.ucas", $"pakchunk3064-{platformCode}.utoc",
        $"pakchunk3065-{platformCode}.pak", $"pakchunk3065-{platformCode}.sig", $"pakchunk3065-{platformCode}.ucas", $"pakchunk3065-{platformCode}.utoc",
        $"pakchunk3066-{platformCode}.pak", $"pakchunk3066-{platformCode}.sig", $"pakchunk3066-{platformCode}.ucas", $"pakchunk3066-{platformCode}.utoc",
        $"pakchunk3502-{platformCode}.pak", $"pakchunk3502-{platformCode}.sig", $"pakchunk3502-{platformCode}.ucas", $"pakchunk3502-{platformCode}.utoc",
        $"pakchunk3504-{platformCode}.pak", $"pakchunk3504-{platformCode}.sig", $"pakchunk3504-{platformCode}.ucas", $"pakchunk3504-{platformCode}.utoc",
        $"pakchunk3506-{platformCode}.pak", $"pakchunk3506-{platformCode}.sig", $"pakchunk3506-{platformCode}.ucas", $"pakchunk3506-{platformCode}.utoc",
        $"pakchunk3507-{platformCode}.pak", $"pakchunk3507-{platformCode}.sig", $"pakchunk3507-{platformCode}.ucas", $"pakchunk3507-{platformCode}.utoc",
        $"pakchunk3508-{platformCode}.pak", $"pakchunk3508-{platformCode}.sig", $"pakchunk3508-{platformCode}.ucas", $"pakchunk3508-{platformCode}.utoc",
        $"pakchunk3509-{platformCode}.pak", $"pakchunk3509-{platformCode}.sig", $"pakchunk3509-{platformCode}.ucas", $"pakchunk3509-{platformCode}.utoc",
        $"pakchunk3511-{platformCode}.pak", $"pakchunk3511-{platformCode}.sig", $"pakchunk3511-{platformCode}.ucas", $"pakchunk3511-{platformCode}.utoc",
        $"pakchunk3514-{platformCode}.pak", $"pakchunk3514-{platformCode}.sig", $"pakchunk3514-{platformCode}.ucas", $"pakchunk3514-{platformCode}.utoc",
        $"pakchunk3515-{platformCode}.pak", $"pakchunk3515-{platformCode}.sig", $"pakchunk3515-{platformCode}.ucas", $"pakchunk3515-{platformCode}.utoc",
        $"pakchunk3516-{platformCode}.pak", $"pakchunk3516-{platformCode}.sig", $"pakchunk3516-{platformCode}.ucas", $"pakchunk3516-{platformCode}.utoc",
        $"pakchunk3517-{platformCode}.pak", $"pakchunk3517-{platformCode}.sig", $"pakchunk3517-{platformCode}.ucas", $"pakchunk3517-{platformCode}.utoc",
        $"pakchunk3518-{platformCode}.pak", $"pakchunk3518-{platformCode}.sig", $"pakchunk3518-{platformCode}.ucas", $"pakchunk3518-{platformCode}.utoc",
        $"pakchunk3520-{platformCode}.pak", $"pakchunk3520-{platformCode}.sig", $"pakchunk3520-{platformCode}.ucas", $"pakchunk3520-{platformCode}.utoc",
        $"pakchunk3524-{platformCode}.pak", $"pakchunk3524-{platformCode}.sig", $"pakchunk3524-{platformCode}.ucas", $"pakchunk3524-{platformCode}.utoc",
        $"pakchunk3525-{platformCode}.pak", $"pakchunk3525-{platformCode}.sig", $"pakchunk3525-{platformCode}.ucas", $"pakchunk3525-{platformCode}.utoc",
        $"pakchunk3527-{platformCode}.pak", $"pakchunk3527-{platformCode}.sig", $"pakchunk3527-{platformCode}.ucas", $"pakchunk3527-{platformCode}.utoc",
        $"pakchunk3529-{platformCode}.pak", $"pakchunk3529-{platformCode}.sig", $"pakchunk3529-{platformCode}.ucas", $"pakchunk3529-{platformCode}.utoc",
        $"pakchunk3533-{platformCode}.pak", $"pakchunk3533-{platformCode}.sig", $"pakchunk3533-{platformCode}.ucas", $"pakchunk3533-{platformCode}.utoc",
        $"pakchunk3534-{platformCode}.pak", $"pakchunk3534-{platformCode}.sig", $"pakchunk3534-{platformCode}.ucas", $"pakchunk3534-{platformCode}.utoc",
        $"pakchunk3536-{platformCode}.pak", $"pakchunk3536-{platformCode}.sig", $"pakchunk3536-{platformCode}.ucas", $"pakchunk3536-{platformCode}.utoc",
        $"pakchunk3537-{platformCode}.pak", $"pakchunk3537-{platformCode}.sig", $"pakchunk3537-{platformCode}.ucas", $"pakchunk3537-{platformCode}.utoc",
        $"pakchunk3538-{platformCode}.pak", $"pakchunk3538-{platformCode}.sig", $"pakchunk3538-{platformCode}.ucas", $"pakchunk3538-{platformCode}.utoc",
        $"pakchunk3712-{platformCode}.pak", $"pakchunk3712-{platformCode}.sig", $"pakchunk3712-{platformCode}.ucas", $"pakchunk3712-{platformCode}.utoc",
        $"pakchunk3717-{platformCode}.pak", $"pakchunk3717-{platformCode}.sig", $"pakchunk3717-{platformCode}.ucas", $"pakchunk3717-{platformCode}.utoc",
        $"pakchunk3718-{platformCode}.pak", $"pakchunk3718-{platformCode}.sig", $"pakchunk3718-{platformCode}.ucas", $"pakchunk3718-{platformCode}.utoc",
        $"pakchunk3719-{platformCode}.pak", $"pakchunk3719-{platformCode}.sig", $"pakchunk3719-{platformCode}.ucas", $"pakchunk3719-{platformCode}.utoc",
        $"pakchunk3726-{platformCode}.pak", $"pakchunk3726-{platformCode}.sig", $"pakchunk3726-{platformCode}.ucas", $"pakchunk3726-{platformCode}.utoc",
        $"pakchunk3727-{platformCode}.pak", $"pakchunk3727-{platformCode}.sig", $"pakchunk3727-{platformCode}.ucas", $"pakchunk3727-{platformCode}.utoc",
        $"pakchunk3730-{platformCode}.pak", $"pakchunk3730-{platformCode}.sig", $"pakchunk3730-{platformCode}.ucas", $"pakchunk3730-{platformCode}.utoc",
        $"pakchunk3732-{platformCode}.pak", $"pakchunk3732-{platformCode}.sig", $"pakchunk3732-{platformCode}.ucas", $"pakchunk3732-{platformCode}.utoc",
        $"pakchunk3733-{platformCode}.pak", $"pakchunk3733-{platformCode}.sig", $"pakchunk3733-{platformCode}.ucas", $"pakchunk3733-{platformCode}.utoc",
        $"pakchunk3738-{platformCode}.pak", $"pakchunk3738-{platformCode}.sig", $"pakchunk3738-{platformCode}.ucas", $"pakchunk3738-{platformCode}.utoc",
        $"pakchunk3739-{platformCode}.pak", $"pakchunk3739-{platformCode}.sig", $"pakchunk3739-{platformCode}.ucas", $"pakchunk3739-{platformCode}.utoc",
        $"pakchunk3740-{platformCode}.pak", $"pakchunk3740-{platformCode}.sig", $"pakchunk3740-{platformCode}.ucas", $"pakchunk3740-{platformCode}.utoc",
        $"pakchunk3742-{platformCode}.pak", $"pakchunk3742-{platformCode}.sig", $"pakchunk3742-{platformCode}.ucas", $"pakchunk3742-{platformCode}.utoc",
        $"pakchunk3743-{platformCode}.pak", $"pakchunk3743-{platformCode}.sig", $"pakchunk3743-{platformCode}.ucas", $"pakchunk3743-{platformCode}.utoc",
        $"pakchunk3744-{platformCode}.pak", $"pakchunk3744-{platformCode}.sig", $"pakchunk3744-{platformCode}.ucas", $"pakchunk3744-{platformCode}.utoc",
        $"pakchunk3745-{platformCode}.pak", $"pakchunk3745-{platformCode}.sig", $"pakchunk3745-{platformCode}.ucas", $"pakchunk3745-{platformCode}.utoc",
        $"pakchunk4-{platformCode}.pak", $"pakchunk4-{platformCode}.sig", $"pakchunk4-{platformCode}.ucas", $"pakchunk4-{platformCode}.utoc",
        $"pakchunk4001-{platformCode}.pak", $"pakchunk4001-{platformCode}.sig", $"pakchunk4001-{platformCode}.ucas", $"pakchunk4001-{platformCode}.utoc",
        $"pakchunk4100-{platformCode}.pak", $"pakchunk4100-{platformCode}.sig", $"pakchunk4100-{platformCode}.ucas", $"pakchunk4100-{platformCode}.utoc",
        $"pakchunk4101-{platformCode}.pak", $"pakchunk4101-{platformCode}.sig", $"pakchunk4101-{platformCode}.ucas", $"pakchunk4101-{platformCode}.utoc",
        $"pakchunk4102-{platformCode}.pak", $"pakchunk4102-{platformCode}.sig", $"pakchunk4102-{platformCode}.ucas", $"pakchunk4102-{platformCode}.utoc",
        $"pakchunk4103-{platformCode}.pak", $"pakchunk4103-{platformCode}.sig", $"pakchunk4103-{platformCode}.ucas", $"pakchunk4103-{platformCode}.utoc",
        $"pakchunk4104-{platformCode}.pak", $"pakchunk4104-{platformCode}.sig", $"pakchunk4104-{platformCode}.ucas", $"pakchunk4104-{platformCode}.utoc",
        $"pakchunk4105-{platformCode}.pak", $"pakchunk4105-{platformCode}.sig", $"pakchunk4105-{platformCode}.ucas", $"pakchunk4105-{platformCode}.utoc",
        $"pakchunk4106-{platformCode}.pak", $"pakchunk4106-{platformCode}.sig", $"pakchunk4106-{platformCode}.ucas", $"pakchunk4106-{platformCode}.utoc",
        $"pakchunk4107-{platformCode}.pak", $"pakchunk4107-{platformCode}.sig", $"pakchunk4107-{platformCode}.ucas", $"pakchunk4107-{platformCode}.utoc",
        $"pakchunk4108-{platformCode}.pak", $"pakchunk4108-{platformCode}.sig", $"pakchunk4108-{platformCode}.ucas", $"pakchunk4108-{platformCode}.utoc",
        $"pakchunk4109-{platformCode}.pak", $"pakchunk4109-{platformCode}.sig", $"pakchunk4109-{platformCode}.ucas", $"pakchunk4109-{platformCode}.utoc",
        $"pakchunk4110-{platformCode}.pak", $"pakchunk4110-{platformCode}.sig", $"pakchunk4110-{platformCode}.ucas", $"pakchunk4110-{platformCode}.utoc",
        $"pakchunk4111-{platformCode}.pak", $"pakchunk4111-{platformCode}.sig", $"pakchunk4111-{platformCode}.ucas", $"pakchunk4111-{platformCode}.utoc",
        $"pakchunk4112-{platformCode}.pak", $"pakchunk4112-{platformCode}.sig", $"pakchunk4112-{platformCode}.ucas", $"pakchunk4112-{platformCode}.utoc",
        $"pakchunk4113-{platformCode}.pak", $"pakchunk4113-{platformCode}.sig", $"pakchunk4113-{platformCode}.ucas", $"pakchunk4113-{platformCode}.utoc",
        $"pakchunk4114-{platformCode}.pak", $"pakchunk4114-{platformCode}.sig", $"pakchunk4114-{platformCode}.ucas", $"pakchunk4114-{platformCode}.utoc",
        $"pakchunk4115-{platformCode}.pak", $"pakchunk4115-{platformCode}.sig", $"pakchunk4115-{platformCode}.ucas", $"pakchunk4115-{platformCode}.utoc",
        $"pakchunk4116-{platformCode}.pak", $"pakchunk4116-{platformCode}.sig", $"pakchunk4116-{platformCode}.ucas", $"pakchunk4116-{platformCode}.utoc",
        $"pakchunk4117-{platformCode}.pak", $"pakchunk4117-{platformCode}.sig", $"pakchunk4117-{platformCode}.ucas", $"pakchunk4117-{platformCode}.utoc",
        $"pakchunk4118-{platformCode}.pak", $"pakchunk4118-{platformCode}.sig", $"pakchunk4118-{platformCode}.ucas", $"pakchunk4118-{platformCode}.utoc",
        $"pakchunk4119-{platformCode}.pak", $"pakchunk4119-{platformCode}.sig", $"pakchunk4119-{platformCode}.ucas", $"pakchunk4119-{platformCode}.utoc",
        $"pakchunk4120-{platformCode}.pak", $"pakchunk4120-{platformCode}.sig", $"pakchunk4120-{platformCode}.ucas", $"pakchunk4120-{platformCode}.utoc",
        $"pakchunk4121-{platformCode}.pak", $"pakchunk4121-{platformCode}.sig", $"pakchunk4121-{platformCode}.ucas", $"pakchunk4121-{platformCode}.utoc",
        $"pakchunk4900-{platformCode}.pak", $"pakchunk4900-{platformCode}.sig", $"pakchunk4900-{platformCode}.ucas", $"pakchunk4900-{platformCode}.utoc",
        $"pakchunk4999-{platformCode}.pak", $"pakchunk4999-{platformCode}.sig", $"pakchunk4999-{platformCode}.ucas", $"pakchunk4999-{platformCode}.utoc",
        $"pakchunk5-{platformCode}.pak", $"pakchunk5-{platformCode}.sig", $"pakchunk5-{platformCode}.ucas", $"pakchunk5-{platformCode}.utoc",
        $"pakchunk5001-{platformCode}.pak", $"pakchunk5001-{platformCode}.sig", $"pakchunk5001-{platformCode}.ucas", $"pakchunk5001-{platformCode}.utoc",
        $"pakchunk5003-{platformCode}.pak", $"pakchunk5003-{platformCode}.sig", $"pakchunk5003-{platformCode}.ucas", $"pakchunk5003-{platformCode}.utoc",
        $"pakchunk5004-{platformCode}.pak", $"pakchunk5004-{platformCode}.sig", $"pakchunk5004-{platformCode}.ucas", $"pakchunk5004-{platformCode}.utoc",
        $"pakchunk5005-{platformCode}.pak", $"pakchunk5005-{platformCode}.sig", $"pakchunk5005-{platformCode}.ucas", $"pakchunk5005-{platformCode}.utoc",
        $"pakchunk5995-{platformCode}.pak", $"pakchunk5995-{platformCode}.sig", $"pakchunk5995-{platformCode}.ucas", $"pakchunk5995-{platformCode}.utoc",
        $"pakchunk5996-{platformCode}.pak", $"pakchunk5996-{platformCode}.sig", $"pakchunk5996-{platformCode}.ucas", $"pakchunk5996-{platformCode}.utoc",
        $"pakchunk5997-{platformCode}.pak", $"pakchunk5997-{platformCode}.sig", $"pakchunk5997-{platformCode}.ucas", $"pakchunk5997-{platformCode}.utoc",
        $"pakchunk5998-{platformCode}.pak", $"pakchunk5998-{platformCode}.sig", $"pakchunk5998-{platformCode}.ucas", $"pakchunk5998-{platformCode}.utoc",
        $"pakchunk5999-{platformCode}.pak", $"pakchunk5999-{platformCode}.sig", $"pakchunk5999-{platformCode}.ucas", $"pakchunk5999-{platformCode}.utoc",
        $"pakchunk6-{platformCode}.pak", $"pakchunk6-{platformCode}.sig", $"pakchunk6-{platformCode}.ucas", $"pakchunk6-{platformCode}.utoc",
        $"pakchunk7-{platformCode}.pak", $"pakchunk7-{platformCode}.sig", $"pakchunk7-{platformCode}.ucas", $"pakchunk7-{platformCode}.utoc",
        $"pakchunk8-{platformCode}.pak", $"pakchunk8-{platformCode}.sig", $"pakchunk8-{platformCode}.ucas", $"pakchunk8-{platformCode}.utoc",
        $"pakchunk9-{platformCode}.pak", $"pakchunk9-{platformCode}.sig", $"pakchunk9-{platformCode}.ucas", $"pakchunk9-{platformCode}.utoc",
        $"pakchunk99-{platformCode}.pak", $"pakchunk99-{platformCode}.sig", $"pakchunk99-{platformCode}.ucas", $"pakchunk99-{platformCode}.utoc"
    };

            string dbdPakFolderPath = GetDbdPakFolderPath();
            if (string.IsNullOrEmpty(dbdPakFolderPath))
            {
                MessageBox.Show("Please select the DBD pak folder first.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var filesToKeep = new HashSet<string>(requiredFiles, StringComparer.OrdinalIgnoreCase);
            var filesToDelete = Directory.GetFiles(dbdPakFolderPath, "*.*", SearchOption.TopDirectoryOnly)
                                         .Where(file => !filesToKeep.Contains(Path.GetFileName(file)));

            foreach (var file in filesToDelete)
            {
                try
                {
                    File.Delete(file);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error deleting file {file}: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            enabledModsListBox.Items.Clear();
            SaveInstalledMods();

            MessageBox.Show("Unnecessary pak files have been removed and the installed mods list has been cleared.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private string GetDbdPakFolderPath()
        {
            string appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string settingsPath = Path.Combine(appDataPath, "DBDModManager", "dbdPakFolderPath.txt");

            if (File.Exists(settingsPath))
            {
                return File.ReadAllText(settingsPath).Trim();
            }

            return null;
        }



        private Panel CreatePanel(DockStyle dock, Padding padding, string backColor, bool visible)
        {
            return new Panel
            {
                Dock = dock,
                Padding = padding,
                BackColor = ColorTranslator.FromHtml(backColor),
                Visible = visible
            };
        }

        private void AddSettingsContentPanel()
        {
            settingsContent = CreatePanel(DockStyle.Fill, new Padding(SidebarWidthCollapsed + 60, 60, 10, 20), BackgroundColor, false);
            this.Controls.Add(settingsContent);

            Label settingsLabel = CreateLabel("Settings", new Font("Arial", 20, FontStyle.Bold), Color.White, new Point(60, 60));
            settingsContent.Controls.Add(settingsLabel);

            Label modManagerAsMainScreenLabel = CreateLabel("Mod Manager as Main Screen:", new Font("Arial", 12, FontStyle.Regular), Color.White, new Point(60, 100));
            settingsContent.Controls.Add(modManagerAsMainScreenLabel);

            modManagerAsMainScreenComboBox = new ComboBox
            {
                Font = new Font("Arial", 12, FontStyle.Regular),
                ForeColor = Color.White,
                BackColor = ColorTranslator.FromHtml("#1a1b26"),
                Location = new Point(400, 100),
                Width = 100,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            modManagerAsMainScreenComboBox.Items.AddRange(new string[] { "N/A", "ON", "OFF" });
            modManagerAsMainScreenComboBox.SelectedIndex = 0;
            modManagerAsMainScreenComboBox.SelectedIndexChanged += ModManagerAsMainScreenComboBox_SelectedIndexChanged;
            settingsContent.Controls.Add(modManagerAsMainScreenComboBox);

            Label noAnimationsLabel = CreateLabel("No Animations:", new Font("Arial", 12, FontStyle.Regular), Color.White, new Point(60, 130));
            settingsContent.Controls.Add(noAnimationsLabel);

            noAnimationsComboBox = new ComboBox
            {
                Font = new Font("Arial", 12, FontStyle.Regular),
                ForeColor = Color.White,
                BackColor = ColorTranslator.FromHtml("#1a1b26"),
                Location = new Point(400, 130),
                Width = 100,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            noAnimationsComboBox.Items.AddRange(new string[] { "OFF", "ON" });
            noAnimationsComboBox.SelectedIndex = 0;
            noAnimationsComboBox.SelectedIndexChanged += NoAnimationsComboBox_SelectedIndexChanged;
            settingsContent.Controls.Add(noAnimationsComboBox);

            Label platformLabel = CreateLabel("Platform:", new Font("Arial", 12, FontStyle.Regular), Color.White, new Point(60, 160));
            settingsContent.Controls.Add(platformLabel);

            platformComboBox = new ComboBox
            {
                Font = new Font("Arial", 12, FontStyle.Regular),
                ForeColor = Color.White,
                BackColor = ColorTranslator.FromHtml("#1a1b26"),
                Location = new Point(400, 160),
                Width = 100,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            platformComboBox.Items.AddRange(new string[] { "Epic Games", "Steam", "Microsoft Store" });
            platformComboBox.SelectedIndex = -1;
            platformComboBox.SelectedIndexChanged += PlatformComboBox_SelectedIndexChanged;
            settingsContent.Controls.Add(platformComboBox);

            Button platformOkButton = new Button
            {
                Text = "OK",
                Font = new Font("Arial", 10, FontStyle.Regular),
                ForeColor = Color.White,
                BackColor = ColorTranslator.FromHtml("#1a1b26"),
                Width = 50,
                Height = 30,
                FlatStyle = FlatStyle.Flat,
                Location = new Point(510, 160)
            };
            platformOkButton.Click += PlatformOkButton_Click;
            settingsContent.Controls.Add(platformOkButton);

            Button helpButton = new Button
            {
                Text = "?",
                Font = new Font("Arial", 12, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = ColorTranslator.FromHtml("#1a1b26"),
                Location = new Point(570, 160),
                Size = new Size(30, 30),
                FlatStyle = FlatStyle.Flat
            };
            helpButton.Click += (sender, e) =>
            {
                MessageBox.Show("Go to your Dead by Daylight pak's folder and look for any of these hints:\n\n" +
                                "EGS/Epic Games: pakchunk files end in \"-EGS\"\n" +
                                "Steam: pakchunk files end in \"-Windows\"\n" +
                                "Microsoft Store: pakchunk files end in \"-WinGDK\"", "Platform Detection Help", MessageBoxButtons.OK, MessageBoxIcon.Information);
            };
            settingsContent.Controls.Add(helpButton);
            Label dbdPakFolderLabel = CreateLabel("Select DBD pak folder:", new Font("Arial", 12, FontStyle.Regular), Color.White, new Point(60, 190));
            settingsContent.Controls.Add(dbdPakFolderLabel);

            Button selectDbdPakFolderButton = new Button
            {
                Text = "Select Folder",
                Font = new Font("Arial", 10, FontStyle.Regular),
                ForeColor = Color.White,
                BackColor = ColorTranslator.FromHtml("#1a1b26"),
                Width = 100,
                Height = 30,
                FlatStyle = FlatStyle.Flat,
                Location = new Point(410, 190)
            };
            selectDbdPakFolderButton.Click += SelectDbdPakFolderButton_Click;
            settingsContent.Controls.Add(selectDbdPakFolderButton);

            TextBox selectedPathTextBox = new TextBox
            {
                Font = new Font("Arial", 10, FontStyle.Regular),
                ForeColor = Color.White,
                BackColor = ColorTranslator.FromHtml("#1a1b26"),
                Location = new Point(510, 195),
                Width = 300,
                ReadOnly = true,
                BorderStyle = BorderStyle.None
            };
            selectedPathTextBox.Name = "selectedPathTextBox"; 
            settingsContent.Controls.Add(selectedPathTextBox);

            Label modFolderLabel = CreateLabel("Select Mod folder:", new Font("Arial", 12, FontStyle.Regular), Color.White, new Point(60, 220));
            settingsContent.Controls.Add(modFolderLabel);

            Button selectModFolderButton = new Button
            {
                Text = "Select Folder",
                Font = new Font("Arial", 10, FontStyle.Regular),
                ForeColor = Color.White,
                BackColor = ColorTranslator.FromHtml("#1a1b26"),
                Width = 100,
                Height = 30,
                FlatStyle = FlatStyle.Flat,
                Location = new Point(410, 220)
            };
            selectModFolderButton.Click += SelectModFolderButton_Click;
            settingsContent.Controls.Add(selectModFolderButton);

            TextBox selectedModPathTextBox = new TextBox
            {
                Font = new Font("Arial", 10, FontStyle.Regular),
                ForeColor = Color.White,
                BackColor = ColorTranslator.FromHtml("#1a1b26"),
                Location = new Point(510, 225),
                Width = 300,
                ReadOnly = true,
                BorderStyle = BorderStyle.None
            };
            selectedModPathTextBox.Name = "selectedModPathTextBox"; 
            settingsContent.Controls.Add(selectedModPathTextBox);

            LoadDbdPakFolderPath(selectedPathTextBox);
            LoadModFolderPath(selectedModPathTextBox);
        }


        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            SaveInstalledMods();
        }
        private void EnableMod(ListBox source, ListBox destination)
        {
            if (source.SelectedItem is ModItem modItem)
            {
                string platformCode = GetPlatformCode();
                if (string.IsNullOrEmpty(platformCode)) return;

                using (var archive = System.IO.Compression.ZipFile.OpenRead(modItem.FilePath))
                {
                    foreach (var entry in archive.Entries)
                    {
                        if (entry.FullName.EndsWith(".pak", StringComparison.OrdinalIgnoreCase) ||
                            entry.FullName.EndsWith(".sig", StringComparison.OrdinalIgnoreCase) ||
                            entry.FullName.EndsWith(".ucas", StringComparison.OrdinalIgnoreCase) ||
                            entry.FullName.EndsWith(".utoc", StringComparison.OrdinalIgnoreCase))
                        {
                            string destinationPath = Path.Combine(selectedDbdPakFolderPath, ReplacePlatformCode(entry.FullName, platformCode));
                            entry.ExtractToFile(destinationPath, true);
                        }
                    }
                }

                destination.Items.Add(modItem);
                source.Items.Remove(modItem);
            }
        }

        private void DisableMod(ListBox source, ListBox destination)
        {
            if (source.SelectedItem is ModItem modItem)
            {
                string platformCode = GetPlatformCode();
                if (string.IsNullOrEmpty(platformCode)) return;

                using (var archive = System.IO.Compression.ZipFile.OpenRead(modItem.FilePath))
                {
                    foreach (var entry in archive.Entries)
                    {
                        if (entry.FullName.EndsWith(".pak", StringComparison.OrdinalIgnoreCase) ||
                            entry.FullName.EndsWith(".sig", StringComparison.OrdinalIgnoreCase) ||
                            entry.FullName.EndsWith(".ucas", StringComparison.OrdinalIgnoreCase) ||
                            entry.FullName.EndsWith(".utoc", StringComparison.OrdinalIgnoreCase))
                        {
                            string filePath = Path.Combine(selectedDbdPakFolderPath, ReplacePlatformCode(entry.FullName, platformCode));
                            if (File.Exists(filePath))
                            {
                                File.Delete(filePath);
                            }
                        }
                    }
                }

                destination.Items.Add(modItem);
                source.Items.Remove(modItem);
            }
        }

        private string ReplacePlatformCode(string input, string platformCode)
        {
            string[] platformCodes = { "EGS", "Windows", "WinGDK" };
            foreach (var code in platformCodes)
            {
                if (input.IndexOf(code, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return input.Replace(code, platformCode);
                }
            }
            return input;
        }


        private void LoadDisabledMods(ListBox listBox)
        {
            listBox.Items.Clear();
            if (string.IsNullOrEmpty(selectedModFolderPath)) return;

            var installedMods = new HashSet<string>(enabledModsListBox.Items.Cast<ModItem>().Select(m => m.ModName));
            var modFiles = Directory.GetFiles(selectedModFolderPath, "*.mmpackage");
            foreach (var modFile in modFiles)
            {
                using (var archive = System.IO.Compression.ZipFile.OpenRead(modFile))
                {
                    var modNameEntry = archive.GetEntry("modname.txt");
                    if (modNameEntry != null)
                    {
                        using (var reader = new StreamReader(modNameEntry.Open()))
                        {
                            string modName = reader.ReadToEnd().Trim();
                            if (!installedMods.Contains(modName))
                            {
                                listBox.Items.Add(new ModItem { FilePath = modFile, ModName = modName });
                            }
                        }
                    }
                }
            }
        }
        private void LoadAllMods(ListBox source, ListBox destination)
        {
            while (source.Items.Count > 0)
            {
                source.SelectedIndex = 0;
                EnableMod(source, destination);
            }
        }
        private void UnloadAllMods(ListBox source, ListBox destination)
        {
            while (source.Items.Count > 0)
            {
                source.SelectedIndex = 0;
                DisableMod(source, destination);
            }
        }
        private string GetPlatformCode()
        {
            if (platformComboBox.SelectedItem == null)
            {
                MessageBox.Show("Please select a platform first.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }

            string selectedPlatform = platformComboBox.SelectedItem.ToString();
            switch (selectedPlatform)
            {
                case "Epic Games":
                    return "EGS";
                case "Steam":
                    return "Windows";
                case "Microsoft Store":
                    return "WinGDK";
                default:
                    return null;
            }
        }

        private void SelectModFolderButton_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog())
            {
                if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
                {
                    selectedModFolderPath = folderBrowserDialog.SelectedPath;
                    SaveModFolderPath(selectedModFolderPath);

                    TextBox selectedModPathTextBox = (TextBox)((Button)sender).Parent.Controls.Find("selectedModPathTextBox", true).FirstOrDefault();
                    if (selectedModPathTextBox != null)
                    {
                        selectedModPathTextBox.Text = selectedModFolderPath;
                    }

                    LoadDisabledMods(disabledModsListBox);
                }
            }
        }
        private void LoadModFolderPath(TextBox selectedModPathTextBox)
        {
            string appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string settingsPath = Path.Combine(appDataPath, "DBDModManager", "modFolderPath.txt");

            if (File.Exists(settingsPath))
            {
                selectedModFolderPath = File.ReadAllText(settingsPath);
                selectedModPathTextBox.Text = selectedModFolderPath;
            }
        }

        private void SaveModFolderPath(string path)
        {
            string appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string settingsDirectory = Path.Combine(appDataPath, "DBDModManager");
            Directory.CreateDirectory(settingsDirectory);

            string settingsPath = Path.Combine(settingsDirectory, "modFolderPath.txt");
            File.WriteAllText(settingsPath, path);
        }

        private void SelectDbdPakFolderButton_Click(object sender, EventArgs e)
        {
            using (FolderSelectorForm folderSelectorForm = new FolderSelectorForm())
            {
                if (folderSelectorForm.ShowDialog() == DialogResult.OK)
                {
                    string selectedPath = folderSelectorForm.SelectedPath;
                    if (!selectedPath.EndsWith("DeadByDaylight\\Content\\Paks"))
                    {
                        DialogResult result = MessageBox.Show("Are you sure this is the correct path?", "Confirm Path", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (result == DialogResult.No)
                        {
                            SelectDbdPakFolderButton_Click(sender, e);
                            return;
                        }
                    }

                    SaveDbdPakFolderPath(selectedPath);

                    TextBox selectedPathTextBox = (TextBox)((Button)sender).Parent.Controls.Find("selectedPathTextBox", true).FirstOrDefault();
                    if (selectedPathTextBox != null)
                    {
                        selectedPathTextBox.Text = selectedPath;
                    }
                }
            }
        }

        private void LoadDbdPakFolderPath(TextBox selectedPathTextBox)
        {
            string appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string settingsPath = Path.Combine(appDataPath, "DBDModManager", "dbdPakFolderPath.txt");

            if (File.Exists(settingsPath))
            {
                selectedDbdPakFolderPath = File.ReadAllText(settingsPath);
                selectedPathTextBox.Text = selectedDbdPakFolderPath;
            }
        }

        private void SaveDbdPakFolderPath(string path)
        {
            string appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string settingsDirectory = Path.Combine(appDataPath, "DBDModManager");
            Directory.CreateDirectory(settingsDirectory);

            string settingsPath = Path.Combine(settingsDirectory, "dbdPakFolderPath.txt");
            File.WriteAllText(settingsPath, path);
        }


        private void LoadDbdPakFolderPath(Label selectedPathLabel)
        {
            string appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string settingsPath = Path.Combine(appDataPath, "DBDModManager", "dbdPakFolderPath.txt");

            if (File.Exists(settingsPath))
            {
                string savedPath = File.ReadAllText(settingsPath);
                selectedPathLabel.Text = savedPath;
            }
        }


        private void PlatformOkButton_Click(object sender, EventArgs e)
        {
            SaveSettings();
            UpdateCurrentProfileLabel();
        }

        private void UpdateCurrentProfileLabel()
        {
            string profileName = profileComboBox.SelectedItem?.ToString();
            string platform = platformComboBox.SelectedItem?.ToString() ?? "Not selected";
            currentProfileLabel.Text = $"Current profile: {profileName} | Platform: {platform}";
        }

        private void NoAnimationsComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            SaveSettings();
            if (((ComboBox)sender).SelectedItem.ToString() == "ON")
            {
                sidebarAnimationTimer.Enabled = false;
                sidebar.Width = sidebarExpanded ? SidebarWidthExpanded : SidebarWidthCollapsed;
                AdjustSingleBox();
                AdjustContentPanels();
            }
            else
            {
                sidebarAnimationTimer.Enabled = true;
            }
        }

        private void ToggleSidebar(object sender, EventArgs e)
        {
            sidebarExpanded = !sidebarExpanded;

            foreach (Control control in sidebar.Controls)
            {
                if (control is Button menuButton && menuButton.Tag != null)
                {
                    menuButton.Visible = sidebarExpanded; 
                }
            }

            if (noAnimationsComboBox.SelectedItem.ToString() == "ON")
            {
                sidebar.Width = sidebarExpanded ? SidebarWidthExpanded : SidebarWidthCollapsed;
                AdjustSingleBox();
                AdjustContentPanels();
            }
            else
            {
                sidebarAnimationTimer.Start();
            }
        }
        private void ModManagerAsMainScreenComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            SaveSettings();
        }

        private void PlaceholderComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            SaveSettings();
        }

        private Label CreateLabel(string text, Font font, Color foreColor, Point location)
        {
            return new Label
            {
                Text = text,
                Font = font,
                ForeColor = foreColor,
                AutoSize = true,
                Location = location
            };
        }

        private Label versionLabel;

        private void AddCustomTitleBar()
        {
            Panel titleBar = CreatePanel(DockStyle.Top, new Padding(0), SidebarColor, true);
            titleBar.Height = 60;
            this.Controls.Add(titleBar);

            Button minimizeButton = CreateButton("_", new Font("Arial", 12, FontStyle.Bold), Color.White, SidebarColor, new Size(40, 30), new Point(this.Width - 90, 5));
            minimizeButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            minimizeButton.Click += (sender, e) => this.WindowState = FormWindowState.Minimized;
            titleBar.Controls.Add(minimizeButton);

            Button closeButton = CreateButton("X", new Font("Arial", 12, FontStyle.Bold), Color.White, SidebarColor, new Size(40, 30), new Point(this.Width - 50, 5));
            closeButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            closeButton.Click += (sender, e) => Application.Exit();
            titleBar.Controls.Add(closeButton);

            headerLabel = CreateLabel("DBD Mod Manager", new Font("Arial", 20, FontStyle.Bold), Color.White, new Point((this.Width / 2) - 120, 5));
            headerLabel.Anchor = AnchorStyles.Top;
            titleBar.Controls.Add(headerLabel);

            currentProfileLabel = CreateLabel("Current profile: ", new Font("Arial", 10, FontStyle.Regular), Color.White, new Point((this.Width / 2) - 130, 35));
            currentProfileLabel.Anchor = AnchorStyles.Top;
            titleBar.Controls.Add(currentProfileLabel);

            versionLabel = CreateLabel($"Version {CurrentVersion}", new Font("Arial", 10, FontStyle.Regular), Color.Gray, new Point(10, 10));
            titleBar.Controls.Add(versionLabel);

            titleBar.MouseDown += TitleBar_MouseDown;
            titleBar.MouseMove += TitleBar_MouseMove;
            titleBar.MouseUp += TitleBar_MouseUp;
        }

        private void TitleBar_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                dragging = true;
                dragCursorPoint = Cursor.Position;
                dragFormPoint = this.Location;
            }
        }

        private void TitleBar_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point diff = Point.Subtract(Cursor.Position, new Size(dragCursorPoint));
                this.Location = Point.Add(dragFormPoint, new Size(diff));
            }
        }

        private void TitleBar_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }
        private void UpdateBoxContent(string title, string content)
        {
            if (singleBox != null)
            {
                foreach (Control control in singleBox.Controls)
                {
                    if (control is Label label && label.Font.Style == FontStyle.Bold)
                    {
                        label.Text = title;
                    }
                    else if (control is Label labelContent)
                    {
                        labelContent.Text = content;
                    }
                }
            }
        }

        private void AddSidebar()
        {
            sidebar = CreatePanel(DockStyle.Left, new Padding(0), SidebarColor, true);
            sidebar.Width = SidebarWidthCollapsed;
            this.Controls.Add(sidebar);

            toggleButton = CreateButton("☰", new Font("Arial", 12, FontStyle.Bold), Color.White, SidebarColor, new Size(40, 40), new Point(5, 10));
            toggleButton.Click += ToggleSidebar;
            sidebar.Controls.Add(toggleButton);

            string[] menuItems = { "Dashboard", "Mod Manager", "Troubleshoot", "Settings", "Exit" };
            for (int i = 0; i < menuItems.Length; i++)
            {
                Button menuButton = CreateButton(menuItems[i], new Font("Arial", 12, FontStyle.Bold), Color.White, SidebarColor, new Size(SidebarWidthExpanded - 20, 30), new Point(10, 60 + i * 40));
                menuButton.TextAlign = ContentAlignment.MiddleLeft;
                menuButton.Tag = menuItems[i];
                menuButton.Visible = sidebarExpanded;

                if (menuItems[i] == "Exit")
                {
                    menuButton.Click += (sender, e) => Application.Exit();
                }
                else if (menuItems[i] == "Dashboard")
                {
                    menuButton.Click += (sender, e) => ShowDashboard();
                }
                else if (menuItems[i] == "Mod Manager")
                {
                    menuButton.Click += (sender, e) => ShowModManager();
                }
                else if (menuItems[i] == "Settings")
                {
                    menuButton.Click += (sender, e) => ShowSettings();
                }
                else if (menuItems[i] == "Troubleshoot")
                {
                    menuButton.Click += (sender, e) => ShowTroubleshoot();
                }

                sidebar.Controls.Add(menuButton);
            }
        }

        private Button CreateButton(string text, Font font, Color foreColor, string backColor, Size size, Point location)
        {
            return new Button
            {
                Text = text,
                Font = font,
                ForeColor = foreColor,
                BackColor = ColorTranslator.FromHtml(backColor),
                FlatStyle = FlatStyle.Flat,
                Size = size,
                Location = location,
                Anchor = AnchorStyles.Top | AnchorStyles.Left
            };
        }

        private void ShowTroubleshoot()
        {
            mainContent.Visible = false;
            modManagerContent.Visible = false;
            settingsContent.Visible = false;
            troubleshootContent.Visible = true;
        }

        private void ShowSettings()
        {
            mainContent.Visible = false;
            modManagerContent.Visible = false;
            settingsContent.Visible = true;
            troubleshootContent.Visible = false;
        }

        private void ShowDashboard()
        {
            mainContent.Visible = true;
            modManagerContent.Visible = false;
            settingsContent.Visible = false;
            troubleshootContent.Visible = false;
        }

        private void ShowModManager()
        {
            mainContent.Visible = false;
            modManagerContent.Visible = true;
            settingsContent.Visible = false;
            troubleshootContent.Visible = false;

            LoadDisabledMods(disabledModsListBox);
        }


        private void AnimateSidebar(object sender, EventArgs e)
        {
            if (sidebarExpanded && sidebar.Width < SidebarWidthExpanded)
            {
                sidebar.Width += 10;
                AdjustSingleBox();
                AdjustContentPanels();
            }
            else if (!sidebarExpanded && sidebar.Width > SidebarWidthCollapsed)
            {
                sidebar.Width -= 10;
                AdjustSingleBox();
                AdjustContentPanels();
            }
            else
            {
                sidebarAnimationTimer.Stop();
            }
        }

        private void AdjustSingleBox()
        {
            if (singleBox != null)
            {
                singleBox.Location = new Point(sidebar.Width + 5, singleBox.Location.Y);
                singleBox.Width = CalculateBoxWidth();
            }

            if (smallBox != null)
            {
                smallBox.Location = new Point(sidebar.Width + 5, singleBox.Bottom + 20);
                smallBox.Width = CalculateBoxWidth() / 2;
            }
        }

        private int CalculateBoxWidth()
        {
            return mainContent.Width - sidebar.Width - 30;
        }

        private void AddSingleBox()
        {
            mainContent.Controls.Clear();

            singleBox = CreateCard("", "", SidebarWidthCollapsed + 5, 60, CalculateBoxWidth(), 400);
            mainContent.Controls.Add(singleBox);

            dashboardWebView = new WebView2
            {
                Dock = DockStyle.None,
                Size = new Size(340, 120),
                Anchor = AnchorStyles.Top | AnchorStyles.Right
            };
            mainContent.Controls.Add(dashboardWebView);
            dashboardWebView.BringToFront();

            dashboardWebView.Location = new Point(
                mainContent.Width - dashboardWebView.Width - 10,
                singleBox.Bottom + 20
            );

            InitializeWebView2(dashboardWebView, @"
<html>
<head>
    <style>
        body { background-color: #1a1b26; color: white; font-family: Arial; margin: 0; padding: 0; }
        iframe { display: block; margin: auto; }
    </style>
</head>
<body>
    <iframe
        title='Discord user embed'
        width='340'
        height='120'
        frameborder='0'
        sandbox='allow-scripts'
        src='https://widgets.vendicated.dev/user?id=342779250912264194&theme=dark&banner=true&full-banner=false&rounded-corners=true&discord-icon=false&badges=true&guess-nitro=true&'>
    </iframe>
</body>
</html>");

            smallBox = CreateCard("", "", SidebarWidthCollapsed + 5, singleBox.Bottom + 20, CalculateBoxWidth() / 2, 180);
            mainContent.Controls.Add(smallBox);
            smallBox.BringToFront();

            LoadSmallBoxContentAsync(smallBox);
        }

        private void AddModManagerContent()
        {
            modManagerContent.Controls.Clear();

            profileComboBox = new ComboBox
            {
                Font = new Font("Arial", 10, FontStyle.Regular),
                ForeColor = Color.White,
                BackColor = ColorTranslator.FromHtml("#1a1b26"),
                Location = new Point(20, 20),
                Width = 150,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            profileComboBox.SelectedIndexChanged += ProfileComboBox_SelectedIndexChanged;
            modManagerContent.Controls.Add(profileComboBox);

            manageProfilesButton = new Button
            {
                Text = "Manage Profiles",
                Font = new Font("Arial", 10, FontStyle.Regular),
                ForeColor = Color.White,
                BackColor = ColorTranslator.FromHtml("#1a1b26"),
                Width = 150,
                Height = 30,
                FlatStyle = FlatStyle.Flat,
                Location = new Point(180, 20)
            };
            manageProfilesButton.Click += ManageProfilesButton_Click;
            modManagerContent.Controls.Add(manageProfilesButton);

            LoadProfiles();
            profileComboBox.Location = new Point(manageProfilesButton.Left, manageProfilesButton.Top + manageProfilesButton.Height + 10);

            Panel modManagerOutline = new Panel
            {
                Location = new Point(20, 60),
                Size = new Size(1160, 620),
                BackColor = ColorTranslator.FromHtml(CardColor),
                BorderStyle = BorderStyle.FixedSingle
            };
            modManagerContent.Controls.Add(modManagerOutline);
            modManagerOutline.BringToFront();

            AddModManagerControls(modManagerOutline);
        }

        private void AddModManagerControls(Panel parentPanel)
        {
            disabledModsListBox = new ListBox
            {
                Location = new Point(20, 20),
                Size = new Size(200, 300)
            };
            parentPanel.Controls.Add(disabledModsListBox);

            enabledModsListBox = new ListBox
            {
                Location = new Point(parentPanel.Width - 220, 20),
                Size = new Size(200, 300)
            };
            parentPanel.Controls.Add(enabledModsListBox);

            Button enableButton = new Button
            {
                Text = ">",
                Location = new Point((parentPanel.Width / 2) - 25, 100),
                Size = new Size(50, 30)
            };
            enableButton.Click += (sender, e) => EnableMod(disabledModsListBox, enabledModsListBox);
            parentPanel.Controls.Add(enableButton);

            Button disableButton = new Button
            {
                Text = "<",
                Location = new Point((parentPanel.Width / 2) - 25, 150),
                Size = new Size(50, 30)
            };
            disableButton.Click += (sender, e) => DisableMod(enabledModsListBox, disabledModsListBox);
            parentPanel.Controls.Add(disableButton);

            Button loadAllButton = new Button
            {
                Text = "Load All",
                Location = new Point(20, 340),
                Size = new Size(200, 30)
            };
            loadAllButton.Click += (sender, e) => LoadAllMods(disabledModsListBox, enabledModsListBox);
            parentPanel.Controls.Add(loadAllButton);

            Button unloadAllButton = new Button
            {
                Text = "Unload All",
                Location = new Point(parentPanel.Width - 220, 340),
                Size = new Size(200, 30)
            };
            unloadAllButton.Click += (sender, e) => UnloadAllMods(enabledModsListBox, disabledModsListBox);
            parentPanel.Controls.Add(unloadAllButton);

            Button reloadButton = new Button
            {
                Text = "Reload",
                Location = new Point((parentPanel.Width / 2) - 25, 200),
                Size = new Size(50, 30)
            };
            reloadButton.Click += (sender, e) => LoadDisabledMods(disabledModsListBox);
            parentPanel.Controls.Add(reloadButton);

            LoadDisabledMods(disabledModsListBox);
        }
        private void AdjustContentPanels()
        {
            mainContent.Padding = new Padding(sidebar.Width + 5, 60, 10, 20);
            modManagerContent.Padding = new Padding(sidebar.Width + 60, 60, 10, 20);
            settingsContent.Padding = new Padding(sidebar.Width + 60, 60, 10, 20);
            troubleshootContent.Padding = new Padding(sidebar.Width + 60, 60, 10, 20);

            foreach (Control control in settingsContent.Controls)
            {
                if (control is Label label && label.Location.X == 60)
                {
                    label.Location = new Point(sidebar.Width + 10, label.Location.Y);
                }
                else if (control is ComboBox comboBox && comboBox.Location.X == 400)
                {
                    comboBox.Location = new Point(sidebar.Width + 350, comboBox.Location.Y);
                }
            }

            if (removePaksButton != null)
            {
                removePaksButton.Location = new Point(sidebar.Width + 10, removePaksButton.Location.Y);
            }

            foreach (Control control in modManagerContent.Controls)
            {
                if (control is Panel modManagerBox)
                {
                    modManagerBox.Location = new Point(sidebar.Width + 5, modManagerBox.Location.Y);
                }
            }
        }



        private void UpdateModsList()
        {
            if (modsListBox == null) return;

            string filter = filterTextBox.Text.ToLower();
            modsListBox.Items.Clear();

            foreach (var mod in mods.Where(m => m.Name.ToLower().Contains(filter)))
            {
                modsListBox.Items.Add($"{mod.Name} - {(mod.Enabled ? "Enabled" : "Disabled")}");
            }
        }
        private void ToggleSelectedMod()
        {
            int index = modsListBox.SelectedIndex;
            if (index >= 0)
            {
                var filteredMods = mods.Where(m => m.Name.ToLower().Contains(filterTextBox.Text.ToLower())).ToList();
                filteredMods[index].Enabled = !filteredMods[index].Enabled;
                UpdateModsList();
            }
        }

        private void AddMod()
        {
            using (Form inputForm = new Form())
            {
                inputForm.Text = "Add Mod";
                inputForm.Size = new Size(300, 150);
                inputForm.FormBorderStyle = FormBorderStyle.FixedDialog;
                inputForm.StartPosition = FormStartPosition.CenterScreen;
                inputForm.MinimizeBox = false;
                inputForm.MaximizeBox = false;

                Label label = new Label() { Left = 10, Top = 20, Text = "Enter the name of the new mod:" };
                TextBox textBox = new TextBox() { Left = 10, Top = 50, Width = 260 };
                Button confirmation = new Button() { Text = "OK", Left = 200, Width = 70, Top = 80, DialogResult = DialogResult.OK };

                confirmation.Click += (sender, e) => { inputForm.Close(); };
                inputForm.Controls.Add(label);
                inputForm.Controls.Add(textBox);
                inputForm.Controls.Add(confirmation);
                inputForm.AcceptButton = confirmation;

                if (inputForm.ShowDialog() == DialogResult.OK)
                {
                    string newModName = textBox.Text;
                    if (!string.IsNullOrWhiteSpace(newModName))
                    {
                        mods.Add(new Mod { Id = mods.Count + 1, Name = newModName, Enabled = false });
                        UpdateModsList();
                    }
                }
            }
        }
        private void SetAllModsEnabled(bool enabled)
        {
            mods.ForEach(mod => mod.Enabled = enabled);
            UpdateModsList();
        }

        private void ProfileComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string profileName = profileComboBox.SelectedItem?.ToString();
            string platform = platformComboBox?.SelectedItem?.ToString() ?? "Select a platform!";
            currentProfileLabel.Text = $"Current profile: {profileName} | Platform: {platform}";
        }

        private void LoadProfiles()
        {
            string appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string profilesPath = Path.Combine(appDataPath, ProfilesFilePath);

            if (File.Exists(profilesPath))
            {
                string[] profiles = File.ReadAllLines(profilesPath);
                profileComboBox.Items.AddRange(profiles);
            }
            else
            {
                profileComboBox.Items.AddRange(new string[] { "Profile 1", "Profile 2", "Profile 3" });
            }

            string defaultProfilePath = Path.Combine(appDataPath, "DBDModManager", "defaultProfile.txt");
            if (File.Exists(defaultProfilePath))
            {
                string defaultProfile = File.ReadAllText(defaultProfilePath).Trim();
                if (profileComboBox.Items.Contains(defaultProfile))
                {
                    profileComboBox.SelectedItem = defaultProfile;
                }
                else if (profileComboBox.Items.Count > 0)
                {
                    profileComboBox.SelectedIndex = 0;
                }
            }
            else if (profileComboBox.Items.Count > 0)
            {
                profileComboBox.SelectedIndex = 0;
            }
        }

        private void SaveProfiles()
        {
            string appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string profilesDirectory = Path.Combine(appDataPath, "DBDModManager");
            Directory.CreateDirectory(profilesDirectory);

            string profilesPath = Path.Combine(profilesDirectory, "profiles.txt");
            using (StreamWriter writer = new StreamWriter(profilesPath))
            {
                foreach (var item in profileComboBox.Items)
                {
                    writer.WriteLine(item);
                }
            }

            string defaultProfilePath = Path.Combine(profilesDirectory, "defaultProfile.txt");
            if (profileComboBox.SelectedItem != null)
            {
                File.WriteAllText(defaultProfilePath, profileComboBox.SelectedItem.ToString());
            }
        }

        private void ManageProfilesButton_Click(object sender, EventArgs e)
        {
            using (ProfileManagerForm profileManagerForm = new ProfileManagerForm(profileComboBox.Items.Cast<string>().ToList(), profileComboBox.SelectedItem?.ToString()))
            {
                if (profileManagerForm.ShowDialog() == DialogResult.OK)
                {
                    profileComboBox.Items.Clear();
                    profileComboBox.Items.AddRange(profileManagerForm.Profiles.ToArray());
                    if (!string.IsNullOrEmpty(profileManagerForm.DefaultProfile))
                    {
                        profileComboBox.SelectedItem = profileManagerForm.DefaultProfile;
                    }
                    SaveProfiles();
                }
            }
        }

        private async void InitializeWebView2(WebView2 webView, string htmlContent)
        {
            await webView.EnsureCoreWebView2Async();
            if (webView.CoreWebView2 != null)
            {
                webView.CoreWebView2.NavigateToString(htmlContent);
            }
        }
        private void UpdateBoxContent(Panel box, string title, string content)
        {
            if (box != null)
            {
                foreach (Control control in box.Controls)
                {
                    if (control is Label label && label.Font.Style == FontStyle.Bold)
                    {
                        label.Text = title;
                    }
                    else if (control is Label labelContent)
                    {
                        labelContent.Text = content;
                    }
                }
            }
        }
        private void ModManagerAsMainScreenCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            SaveSettings();
        }

        private void PlaceholderCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            SaveSettings();
        }

        private void LoadSettings()
        {
            string appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string settingsPath = Path.Combine(appDataPath, SettingsFilePath);

            if (File.Exists(settingsPath))
            {
                string[] settings = File.ReadAllLines(settingsPath);
                foreach (string setting in settings)
                {
                    if (setting.StartsWith("ModManagerAsMainScreen="))
                    {
                        if (modManagerAsMainScreenComboBox != null)
                        {
                            modManagerAsMainScreenComboBox.SelectedItem = setting.Split('=')[1];
                        }
                    }
                    else if (setting.StartsWith("NoAnimations="))
                    {
                        if (noAnimationsComboBox != null)
                        {
                            noAnimationsComboBox.SelectedItem = setting.Split('=')[1];
                        }
                    }
                    else if (setting.StartsWith("Platform="))
                    {
                        if (platformComboBox != null)
                        {
                            string savedPlatform = setting.Split('=')[1];
                            platformComboBox.SelectedItem = savedPlatform;
                            if (platformComboBox.SelectedItem == null)
                            {
                                platformComboBox.Items.Insert(0, savedPlatform);
                                platformComboBox.SelectedItem = savedPlatform;
                            }
                        }
                    }
                    else if (setting.StartsWith("PlaceholderOption"))
                    {
                        int index = int.Parse(setting.Split('=')[0].Replace("PlaceholderOption", "")) - 1;
                        if (index >= 0 && index < placeholderComboBoxes.Length && placeholderComboBoxes[index] != null)
                        {
                            placeholderComboBoxes[index].SelectedItem = setting.Split('=')[1];
                        }
                    }
                }
            }

            if (modManagerAsMainScreenComboBox != null && modManagerAsMainScreenComboBox.SelectedItem != null && modManagerAsMainScreenComboBox.SelectedItem.ToString() == "ON")
            {
                ShowModManager();
            }
            else
            {
                ShowDashboard();
            }

            if (noAnimationsComboBox != null && noAnimationsComboBox.SelectedItem != null && noAnimationsComboBox.SelectedItem.ToString() == "ON")
            {
                sidebarAnimationTimer.Enabled = false;
            }
            else
            {
                sidebarAnimationTimer.Enabled = true;
            }

            UpdateCurrentProfileLabel();
            TextBox selectedPathTextBox = (TextBox)settingsContent.Controls.Find("selectedPathTextBox", true).FirstOrDefault();
            if (selectedPathTextBox != null)
            {
                LoadDbdPakFolderPath(selectedPathTextBox);
            }
            else
            {
                MessageBox.Show("selectedPathTextBox not found.");
            }
        }

        private void SaveInstalledMods()
        {
            string appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string installedModsPath = Path.Combine(appDataPath, InstalledModsFilePath);
            Directory.CreateDirectory(Path.GetDirectoryName(installedModsPath));

            using (StreamWriter writer = new StreamWriter(installedModsPath))
            {
                foreach (ModItem modItem in enabledModsListBox.Items)
                {
                    writer.WriteLine(modItem.FilePath);
                }
            }
        }

        private void LoadInstalledMods()
        {
            string appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string installedModsPath = Path.Combine(appDataPath, InstalledModsFilePath);

            if (File.Exists(installedModsPath))
            {
                using (StreamReader reader = new StreamReader(installedModsPath))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (File.Exists(line))
                        {
                            using (var archive = System.IO.Compression.ZipFile.OpenRead(line))
                            {
                                var modNameEntry = archive.GetEntry("modname.txt");
                                if (modNameEntry != null)
                                {
                                    using (var modNameReader = new StreamReader(modNameEntry.Open()))
                                    {
                                        string modName = modNameReader.ReadToEnd().Trim();
                                        enabledModsListBox.Items.Add(new ModItem { FilePath = line, ModName = modName });
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        private void SaveSettings()
        {
            string appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string settingsDirectory = Path.Combine(appDataPath, "DBDModManager");
            Directory.CreateDirectory(settingsDirectory);

            string settingsPath = Path.Combine(settingsDirectory, "settings.txt");
            using (StreamWriter writer = new StreamWriter(settingsPath))
            {
                writer.WriteLine($"ModManagerAsMainScreen={modManagerAsMainScreenComboBox.SelectedItem}");
                if (noAnimationsComboBox != null && noAnimationsComboBox.SelectedItem != null)
                {
                    writer.WriteLine($"NoAnimations={noAnimationsComboBox.SelectedItem}");
                }
                else
                {
                    writer.WriteLine("NoAnimations=default"); 
                }

                if (platformComboBox != null && platformComboBox.SelectedItem != null)
                {
                    writer.WriteLine($"Platform={platformComboBox.SelectedItem}");
                }
                else
                {
                    writer.WriteLine("Platform=default");
                }

                }
            }
        }
        public class ModItem
        {
            public string FilePath { get; set; }
            public string ModName { get; set; }

            public override string ToString()
            {
                return ModName;
            }
        }
    }
